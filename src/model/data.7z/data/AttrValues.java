package model.data;

import com.database.QueryRow;
import com.model.DataSet_old;
import com.database.model.DbItem_old;
import com.database.model.DbModel_old;
import com.database.queries.MultipleQuery;
import static com.model.DataSet_old.DataType.*;
import com.servlet.interfaces.Arg;
import com.utils.Is;
import com.utils.collections.Strings;
import com.utils.date.TDate;
import com.webapi.core.WebApi;
import com.webapi.core.WebApiEndpoint;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import model.data.AttrValues.AttrValue;

public class AttrValues extends DbModel_old<AttrValue, Integer> implements WebApi {

    public final DbCol<Integer> id = new DbCol<Integer>(INT, "id", "ID", a -> a.id).primaryKey(true);
    public final DbCol<TDate> created = new DbCol<>(DATE, "created", "Utworzono", a -> a.created);
    public final DbCol<Integer> groupIst = new DbCol<>(INT, "groupIst", "Instancja", a -> a.groupIst);
    public final DbCol<Integer> groupAttr = new DbCol<>(INT, "groupAttr", "Atrybut", a -> a.groupAttr);
    public final DbCol<Integer> resource = new DbCol<>(INT, "resource", "Zasób", a -> a.resource);
    public final DbCol<Strings> value = new DbCol<>(ARRAY, "value", "Wartość", a -> a.value);
    public final DbCol<Integer> cryptKey = new DbCol<>(INT, "cryptKey", "Klucz szyfrujący", a -> a.cryptKey);
    public final DbCol<String> notes = new DbCol<>(INT, "notes", "Notatki", a -> a.notes);

    public AttrValues() {
        super(AttrValue.class, "attrValue", "Wartość atrybutu");

    }

    @Override
    protected void buildQuery(MultipleQuery mqry) {
        mqry.query("SELECT * FROM data.attribute_value");
    }

    @Override
    protected void onRemove(AttrValue item) {

    }

    @WebApiEndpoint
    public DataSet_old getAll() {
        return getDataSet();
    }

    @WebApiEndpoint
    public void remove(@Arg(name = "id") Integer id) {
        getByKeyF(id).remove();
    }

    @WebApiEndpoint
    public void edit(
            @Arg(name = "id") Integer id,
            @Arg(name = "name") String name,
            @Arg(name = "content") String content
    ) {

        // Devices.Device doc = Is.nullR(id, () -> new Devices.Device(this), x -> getByKeyF(x));
    }

    public class AttrValue extends DbItem_old<Integer> {

        public Integer id;

        public Integer groupIst;
        public Integer groupAttr;
        public Integer resource;
        public TDate created;
        public Strings value;
        public Integer cryptKey;
        public String notes;

        public AttrValue(AttrValues parent, QueryRow row) throws SQLException {
            super(parent);
            id = row.getInt("id");
            created = row.getDate("created");
            groupIst = row.getInt("group_ist", null);
            groupAttr = row.getInt("group_attr", null);
            resource = row.getInt("resource", null);
            value = row.getArray("value");
            cryptKey = row.getInt("crypt_key", null);
            notes = row.getStr("notes", null);
        }

        @Override
        public String getDisplayValue() {
            return name;
        }

        @Override
        protected Integer getKeyValue() {
            return id;
        }

        @Override
        protected void buildUpdateQuery(MultipleQuery query, List<DbItem_old<?>> items) throws SQLException {

        }

    }

}
