package model.data;

import com.database.QueryRow;
import com.model.DataSet_old;
import com.database.model.DbItem_old;
import com.database.model.DbModel_old;
import com.database.queries.MultipleQuery;
import static com.model.DataSet_old.DataType.*;
import com.servlet.interfaces.Arg;
import com.utils.collections.Strings;
import com.utils.date.TDate;
import com.webapi.core.WebApi;
import com.webapi.core.WebApiEndpoint;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import model.data.AttrDefines.AttrDefine;

public class AttrDefines extends DbModel_old<AttrDefine, Integer> implements WebApi {

    public final DbCol<Integer> id = new DbCol<Integer>(INT, "id", "ID", a -> a.id).primaryKey(true);
    public final DbCol<TDate> created = new DbCol<>(DATE, "created", "Utworzono", a -> a.created);
    public final DbCol<String> key = new DbCol<>(STRING, "key", "Klucz", a -> a.key);
    public final DbCol<Integer> parent = new DbCol<>(INT, "parent", "Rodzic", a -> a.parent);
    public final DbCol<String> name = new DbCol<>(STRING, "name", "Nazwa", a -> a.name);
    public final DbCol<String> desc = new DbCol<>(STRING, "desc", "Opis", a -> a.description);
    public final DbCol<Boolean> required = new DbCol<>(BOOLEAN, "required", "Wymagany", a -> a.required);
    public final DbCol<Strings> defVal = new DbCol<>(ARRAY, "defVal", "Wartość domyślna", a -> a.defVal);
    public final DbCol<List<Integer>> elements = new DbCol<>(ARRAY, "elements", "Elementy", a -> a.elements);

    public AttrDefines() {
        super(AttrDefine.class, "attrElm", "Element atrybutu");

    }

    @Override
    protected void buildQuery(MultipleQuery mqry) {
        mqry.query("SELECT * FROM data.attr_define");
    }

    @Override
    protected void onRemove(AttrDefine item) {

    }

    @WebApiEndpoint
    public DataSet_old getAll() {
        return getDataSet();
    }

    @WebApiEndpoint
    public void remove(@Arg(name = "id") Integer id) {
        getByKeyF(id).remove();
    }

    @WebApiEndpoint
    public void edit(
            @Arg(name = "id") Integer id,
            @Arg(name = "name") String name,
            @Arg(name = "content") String content
    ) {

        // Devices.Device doc = Is.nullR(id, () -> new Devices.Device(this), x -> getByKeyF(x));
    }

    public class AttrDefine extends DbItem_old<Integer> {

        public Integer id;
        public TDate created;
        public String name;
        public String key;
        public String description;
        public Integer parent;
        public List<Integer> elements;
        public Strings defVal;
        public Boolean required;

        public AttrDefine(AttrDefines _parent, QueryRow row) throws SQLException {
            super(_parent);
            id = row.getInt("id");
            created = row.getDate("created");
            parent = row.getInt("parent", null);
            name = row.getStr("name");
            key = row.getStr("key", null);
            description = row.getStr("description", null);
            required = row.getBool("required", null);
            defVal = row.getArray("def_val");
        }

        @Override
        public String getDisplayValue() {
            return name;
        }

        @Override
        protected Integer getKeyValue() {
            return id;
        }

        @Override
        protected void buildUpdateQuery(MultipleQuery query, List<DbItem_old<?>> items) throws SQLException {

        }

    }

}
