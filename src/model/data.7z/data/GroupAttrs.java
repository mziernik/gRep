package model.data;

import com.database.QueryRow;
import com.model.DataSet_old;
import com.database.model.DbItem_old;
import com.database.model.DbModel_old;
import com.database.queries.MultipleQuery;
import static com.model.DataSet_old.DataType.*;
import com.servlet.interfaces.Arg;
import com.utils.Is;
import com.utils.collections.Strings;
import com.webapi.core.WebApi;
import com.webapi.core.WebApiEndpoint;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import model.data.GroupAttrs.GroupAttr;

public class GroupAttrs extends DbModel_old<GroupAttr, Integer> implements WebApi {

    public final DbCol<Integer> id = new DbCol<Integer>(INT, "id", "ID", a -> a.id).primaryKey(true);
    public final DbCol<String> key = new DbCol<>(STRING, "key", "Klucz", a -> a.name);
    public final DbCol<String> type = new DbCol<>(STRING, "type", "Typ", a -> "" + a.type);
    public final DbCol<String> name = new DbCol<>(STRING, "name", "Nazwa", a -> a.name);
    public final DbCol<String> desc = new DbCol<>(STRING, "desc", "Opis", a -> a.description);
    public final DbCol<Boolean> required = new DbCol<>(BOOLEAN, "required", "Wymagany", a -> a.required);
    public final DbCol<Strings> defVal = new DbCol<>(ARRAY, "defVal", "Wartość domyślna", a -> a.defVal);
    public final DbCol<Integer> min = new DbCol<>(INT, "min", "Minimum", a -> a.min);
    public final DbCol<Integer> max = new DbCol<>(INT, "max", "Maksimum", a -> a.max);
    public final DbCol<String> regex = new DbCol<>(STRING, "regex", "Wyrażenie sprawdzające", a -> a.regex);
    public final DbCol<Integer> foreignElm = new DbCol<>(INT, "foreignElm", "Element zewnętrzny", a -> a.foreignElm);
    public final DbCol<Boolean> encrypted = new DbCol<>(BOOLEAN, "encrypted", "Zaszyfrowany", a -> a.encrypted);
    public final DbCol<Map<String, String>> enumerate = new DbCol<>(OBJECT, "enum", "Enumerata", a -> a.enumerate);

    public GroupAttrs() {
        super(GroupAttr.class, "attrElm", "Element atrybutu");

    }

    @Override
    protected void buildQuery(MultipleQuery mqry) {
        mqry.query("SELECT * FROM data.attr_element");
    }

    @Override
    protected void onRemove(GroupAttr item) {

    }

    @WebApiEndpoint
    public DataSet_old getAll() {
        return getDataSet();
    }

    @WebApiEndpoint
    public void remove(@Arg(name = "id") Integer id) {
        getByKeyF(id).remove();
    }

    @WebApiEndpoint
    public void edit(
            @Arg(name = "id") Integer id,
            @Arg(name = "name") String name,
            @Arg(name = "content") String content
    ) {

        // Devices.Device doc = Is.nullR(id, () -> new Devices.Device(this), x -> getByKeyF(x));
    }

    public class GroupAttr extends DbItem_old<Integer> {

        public Integer id;
        public String name;
        public Integer groupDefine;
        public Integer attrDefine;
        
        
        public Character type;
        public String description;
        public Boolean required;
        public Strings defVal;
        public Integer min;
        public Integer max;
        public String regex;
        public Integer foreignElm;
        public Boolean encrypted;
        public Map<String, String> enumerate;

        public GroupAttr(GroupAttrs parent, QueryRow row) throws SQLException {
            super(parent);
            id = row.getInt("id");
            name = row.getStr("name");
            description = row.getStr("description", null);
            type = row.getChar("type");
            required = row.getBool("required");
            defVal = row.getArray("def_val");
            min = row.getInt("min", null);
            max = row.getInt("max", null);
            regex = row.getStr("regex", null);
            foreignElm = row.getInt("foreign_elm", null);
            encrypted = row.getBool("encrypted");
            enumerate = row.getMapString("enumerate");
        }

        @Override
        public String getDisplayValue() {
            return name;
        }

        @Override
        protected Integer getKeyValue() {
            return id;
        }

        @Override
        protected void buildUpdateQuery(MultipleQuery query, List<DbItem_old<?>> items) throws SQLException {

        }

    }

}
