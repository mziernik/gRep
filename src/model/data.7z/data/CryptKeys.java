package model.data;

import com.database.QueryRow;
import com.database.model.DbItem_old;
import com.database.model.DbModel_old;
import com.database.queries.MultipleQuery;
import com.utils.date.TDate;
import java.sql.SQLException;
import java.util.List;
import model.data.CryptKeys.CryptKey;

public class CryptKeys extends DbModel_old<CryptKey, Integer> {

    public CryptKeys() {
        super(CryptKey.class, "attrElm", "Element atrybutu");

    }

    @Override
    protected void buildQuery(MultipleQuery mqry) {
        mqry.query("SELECT * FROM data.crypt_key");
    }

    @Override
    protected void onRemove(CryptKey item) {

    }

    public class CryptKey extends DbItem_old<Integer> {

        public Integer id;
        public TDate created;
        public Integer userId;
        public String serviceKey;
        public String userKey;
        public String md5;

        public CryptKey(CryptKeys parent, QueryRow row) throws SQLException {
            super(parent);
            id = row.getInt("id");
            created = row.getDate("created");
            userId = row.getInt("user_id", null);
            serviceKey = row.getStr("service_key", null);
            userKey = row.getStr("user_key", null);
            md5 = row.getStr("md5");
        }

        @Override
        public String getDisplayValue() {
            return Integer.toString(id);

        }

        @Override
        protected Integer getKeyValue() {
            return id;
        }

        @Override
        protected void buildUpdateQuery(MultipleQuery query, List<DbItem_old<?>> items) throws SQLException {

        }

    }

}
