/**
 * Sekcja zawierająca nagłówek, treść oraz znacznik po lewej stronie
 * http://getbootstrap.com/components/#glyphicons-how-to-use
 */

import SyncfusionComponent from "./SyncfusionComponent.js";
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

import $ from "jquery";
import "./script/ej.datepicker";

export default class DatePicker extends SyncfusionComponent {

    constructor() {
        super(...arguments);
    }

    create(element: HTMLElement) {
        $(element).ejDatePicker({
            locale: this.locale,
            value: new Date()
        });
    }

    render() {
        return <input type="text" ref={e => this.create(e)}/>
    }

}