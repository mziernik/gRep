/**
 * Sekcja zawierająca nagłówek, treść oraz znacznik po lewej stronie
 * http://getbootstrap.com/components/#glyphicons-how-to-use
 */

import SyncfusionComponent from "./SyncfusionComponent.js";
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

import $ from "jquery";
import "./script/ej.schedule";

export default class Kanban extends SyncfusionComponent {

    constructor() {
        super(...arguments);
    }

    create(element: HTMLElement) {
        var data = [
            {
                Id: 1,
                Subject: "Wymiana żarówki",
                StartTime: new Date(2014, 4, 5, 7, 0),
                EndTime: new Date(2014, 4, 5, 9, 0),
                Description: "",
                ownerId: 1
            },

            {
                Id: 2,
                Subject: "Inwentaryzacja",
                StartTime: new Date(2014, 4, 5, 8, 0),
                EndTime: new Date(2014, 4, 5, 14, 0),
                Description: "",
                ownerId: 7
            },
            {
                Id: 3,
                Subject: "Przegląd faktur",
                StartTime: new Date(2014, 4, 6, 8, 0),
                EndTime: new Date(2014, 4, 6, 13, 30),
                Recurrence: true,
                RecurrenceRule: "FREQ=DAILY;INTERVAL=1;COUNT=15",
                ownerId: 3
            },
            {
                Id: 4,
                Subject: "Naprawa maszyny CNC ",
                StartTime: new Date(2014, 4, 5, 7, 30),
                EndTime: new Date(2014, 4, 5, 13, 45),
                Recurrence: true,
                RecurrenceRule: "FREQ=DAILY;INTERVAL=1;COUNT=3",
                ownerId: 5
            },
            {
                Id: 5,
                Subject: "Poprawa oświetlenia",
                StartTime: new Date(2014, 4, 6, 9, 0),
                EndTime: new Date(2014, 4, 6, 14, 0),
                ownerId: 1
            },
            {
                Id: 6,
                Subject: "Naprawa wiertarki ",
                StartTime: new Date(2014, 4, 6, 7, 30),
                EndTime: new Date(2014, 4, 6, 14, 0),
                ownerId: 2
            }
        ];


        for (var i = 1; i < 5; i++)
            data.push({
                Id: i * -1,
                Subject: "Spotkanie (cykliczne)",
                StartTime: new Date(2014, 4, 3, 6, 0),
                EndTime: new Date(2014, 4, 3, 7, 0),
                Description: "",
                AllDay: false,
                Recurrence: true,
                RecurrenceRule: "FREQ=DAILY;INTERVAL=1;COUNT=55",
                ownerId: i
            });


        $(element).ejSchedule({
            locale: this.locale,
            width: "100%",
            cellWidth: "40px",
            height: "800px",
            startHour: 8,
            endHour: 16,
            orientation: "horizontal",
            showCurrentTimeIndicator: false,
            currentView: ej.Schedule.CurrentView.Workweek,
            resourceHeaderTemplateId: "#resTemplate",
            currentDate: new Date(2014, 4, 5),
            group: {
                resources: ["Rooms", "Owners"]
            },
            resources: [{
                field: "ownerId",
                title: "Owner",
                name: "Owners", allowMultiple: true,
                resourceSettings: {
                    dataSource: [
                        {text: "Jan Nowak", id: 1, color: "#ffaa00"},
                        {text: "Bartłomiej Woźniak", id: 2, color: "#f8a398"},
                        {text: "Magdalena Kowalska", id: 3, color: "#51a0ed"},
                        {text: "Krzysztof Borys", id: 4, color: "yellowgreen"},
                        {text: "Kinga Radwańska", id: 5, color: "blue"}
                    ],
                    text: "text", id: "id", groupId: "groupId", color: "color"
                }
            }],
            appointmentSettings: {
                dataSource: data,
                id: "Id",
                subject: "Subject",
                startTime: "StartTime",
                endTime: "EndTime",
                description: "Description",
                allDay: "AllDay",
                recurrence: "Recurrence",
                recurrenceRule: "RecurrenceRule",
                resourceFields: "roomId,ownerId"
            }
        });
    }

    render() {
        return <div ref={e => this.create(e)}/>
    }

}