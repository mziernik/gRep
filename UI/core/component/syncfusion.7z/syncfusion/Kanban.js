/**
 * Sekcja zawierająca nagłówek, treść oraz znacznik po lewej stronie
 * http://getbootstrap.com/components/#glyphicons-how-to-use
 */

import SyncfusionComponent from "./SyncfusionComponent.js";
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

import $ from "jquery";
import "./script/ej.kanban";

export default class Kanban extends SyncfusionComponent {

    constructor() {
        super(...arguments);
    }

    create(element: HTMLElement) {

        var imagePath = window.sample ? "content" : "../content"

        var data = [

            {
                Id: 1,
                Status: "1",
                Summary: "Zadanie 1",
                Type: "Story",
                Priority: "Low",
                Tags: "Analyze,Customer",
                Estimate: 3.5,
                Assignee: "Jan nowak",
                ImgUrl: imagePath + "/images/kanban/7.png",
                RankId: 1
            }, {
                Id: 2,
                Status: "2",
                Summary: "Zadanie 1",
                Type: "Improvement",
                Priority: "Normal",
                Tags: "Improvement",
                Estimate: 6,
                Assignee: "Bartłomiej Woźniak",
                ImgUrl: imagePath + "/images/kanban/2.png",
                RankId: 1
            }, {
                Id: 3,
                Status: "1",
                Summary: "Zadanie 1",
                Type: "Others",
                Priority: "Critical",
                Tags: "Meeting",
                Estimate: 5.5,
                Assignee: "Magdalena Kowalska",
                ImgUrl: imagePath + "/images/kanban/4.png",
                RankId: 2
            }, {
                Id: 4,
                Status: "3",
                Summary: "Zadanie 1",
                Type: "Bug",
                Priority: "Release Breaker",
                Tags: "IE",
                Estimate: 2.5,
                Assignee: "Kinga Radwańska",
                ImgUrl: imagePath + "/images/kanban/3.png",
                RankId: 2
            }, {
                Id: 5,
                Status: "2",
                Summary: "Zadanie 1",
                Type: "Bug",
                Priority: "Low",
                Tags: "Customer",
                Estimate: "3.5",
                Assignee: "Kinga Radwańska",
                ImgUrl: imagePath + "/images/kanban/3.png",
                RankId: 1
            }, {
                Id: 6,
                Status: "4",
                Summary: "Zadanie 1",
                Type: "Others",
                Priority: "Low",
                Tags: "Meeting",
                Assignee: "Jan nowak",
                ImgUrl: imagePath + "/images/kanban/7.png",
                RankId: 1
            }, {
                Id: 7,
                Status: "1",
                Summary: "Zadanie 1",
                Type: "Improvement",
                Priority: "Low",
                Tags: "Validation",
                Estimate: 1.5,
                Assignee: "Magdalena Kowalska",
                ImgUrl: imagePath + "/images/kanban/4.png",
                RankId: 1
            }, {
                Id: 8,
                Status: "2",
                Summary: "Zadanie 1",
                Type: "Story",
                Priority: "Release Breaker",
                Tags: "Validation,Fix",
                Estimate: 2.5,
                Assignee: "Jan nowak",
                ImgUrl: imagePath + "/images/kanban/7.png",
                RankId: 2
            }];


        $(element).ejKanban(
            {
                locale: "pl-PL",
                dataSource: data,
                allowScrolling: true,

                columns: [
                    {headerText: "Zgłoszone", key: "1", width: 250},
                    {headerText: "Realizacja", key: "2", width: 220},
                    {headerText: "Weryfikacja", key: "3", width: 220},
                    {headerText: "Zatwierdzenie", key: "4", width: 250}
                ],
                keyField: "Status",
                allowTitle: true,
                fields: {
                    primaryKey: "Id",
                    swimlaneKey: "Assignee",
                    content: "Summary",
                    imageUrl: "ImgUrl"
                },
                allowSelection: false
            });
    }

    render() {
        return <div ref={e => this.create(e)}/>
    }

}