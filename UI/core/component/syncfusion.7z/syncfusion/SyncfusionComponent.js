import Component from "../../core/component/Component";
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import $ from 'jquery';

import "./common/ej.core";
import "./common/ej.data";
import "./common/ej.draggable";
import "./common/ej.globalize";
import "./common/ej.scroller";
import "./common/ej.touch";
import "./common/ej.unobtrusive";
import "./common/ej.core";

import  "./i18n/ej.culture.pl-PL";
import  "./l10n/ej.localetexts.pl-PL";

import  "./style/default-theme/ej.web.all.min.css";

export default class SyncfusionComponent extends Component {


    constructor() {
        super(...arguments);
     //   ej.LocaleManager.setLocale("pl-PL");
    }

    locale: String = "pl-PL";
    // ejElement: HTMLElement; // element
    //
    //
    // _setRef(elm) {
    //     if (this.ejElement === elm)
    //         return;
    //     this.ejElement = elm;
    //     this.build($(elm));
    // }
    //
    // render() {
    //     return <div ref={e => this._setRef(e)}>{this.build()}</div>
    // }
}