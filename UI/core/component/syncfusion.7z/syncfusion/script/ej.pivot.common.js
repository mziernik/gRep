/*!
 *  filename: ej.pivot.common.js
 *  version : 15.2.0.40
 *  Copyright Syncfusion Inc. 2001 - 2017. All rights reserved.
 *  Use of this code is subject to the terms of our license.
 *  A copy of the current license can be obtained at any time by e-mailing
 *  licensing@syncfusion.com. Any infringement will be prosecuted under
 *  applicable laws.
 */
(function (fn) {
    typeof define === 'function' && define.amd ? define(["./../common/ej.core"], fn) : fn();
})
(function () {

    ej.Pivot = ej.Pivot || {};

    (function ($, ej, undefined) {

        ej.Pivot = {

            //Report Manipulations
            addReportItem: function (dataSource, args) {
                if (!args.isMeasuresDropped) {
                    var reportItem = this.removeReportItem(dataSource, args.droppedFieldName, args.isMeasuresDropped);
                    if (ej.isNullOrUndefined(reportItem)) reportItem = {
                        fieldName: args.droppedFieldName,
                        fieldCaption: args.droppedFieldCaption
                    };
                    switch (args.droppedClass) {
                        case "row":
                            args.droppedPosition.toString() != "" ? dataSource.rows.splice(args.droppedPosition, 0, reportItem) : dataSource.rows.push(reportItem);
                            break;
                        case "column":
                            args.droppedPosition.toString() != "" ? dataSource.columns.splice(args.droppedPosition, 0, reportItem) : dataSource.columns.push(reportItem);
                            break;
                        case "value":
                            if (dataSource.cube == "")
                                args.droppedPosition.toString() != "" ? dataSource.values.splice(args.droppedPosition, 0, reportItem) : dataSource.values.push(reportItem);
                            else
                                args.droppedPosition.toString() != "" ? dataSource.values[0].measures.splice(args.droppedPosition, 0, reportItem) : dataSource.values[0].measures.push(reportItem);
                            break;
                        case "filter":
                            args.droppedPosition.toString() != "" ? dataSource.filters.splice(args.droppedPosition, 0, reportItem) : dataSource.filters.push(reportItem);
                            break;
                    }
                }
                else {
                    if (args.droppedClass != "")
                        dataSource.values[0].axis = args.droppedClass == "row" ? "rows" : args.droppedClass == "column" ? "columns" : dataSource.values[0].axis;
                    else
                        dataSource.values[0].measures = [];
                }
            },

            removeReportItem: function (dataSource, droppedFieldName, isMeasuresDropped) {
                var analysisMode = dataSource.cube == "" ? ej.Pivot.AnalysisMode.Pivot : ej.Pivot.AnalysisMode.Olap;
                var reportItem = $.grep(dataSource.columns, function (value) {
                    return value.fieldName == droppedFieldName;
                });
                if (!isMeasuresDropped) {
                    if (reportItem.length > 0) dataSource.columns = $.grep(dataSource.columns, function (value) {
                        return value.fieldName != droppedFieldName;
                    });
                    else {
                        reportItem = $.grep(dataSource.rows, function (value) {
                            return value.fieldName == droppedFieldName;
                        });
                        if (reportItem.length > 0) dataSource.rows = $.grep(dataSource.rows, function (value) {
                            return value.fieldName != droppedFieldName;
                        });
                        else {
                            var valueItems = (analysisMode == ej.Pivot.AnalysisMode.Olap ? dataSource.values[0]["measures"] : dataSource.values);
                            reportItem = $.grep(valueItems, function (value) {
                                return value.fieldName == droppedFieldName;
                            });
                            if (reportItem.length > 0)
                                dataSource.values = analysisMode == ej.Pivot.AnalysisMode.Olap ? [{
                                    measures: $.grep(valueItems, function (value) {
                                        return value.fieldName != droppedFieldName;
                                    }), axis: dataSource.values[0].axis
                                }] : $.grep(valueItems, function (value) {
                                    return value.fieldName != droppedFieldName;
                                });
                            else {
                                reportItem = $.grep(dataSource.filters, function (value) {
                                    return value.fieldName == droppedFieldName;
                                });
                                if (reportItem.length > 0) dataSource.filters = $.grep(dataSource.filters, function (value) {
                                    return value.fieldName != droppedFieldName;
                                });
                            }
                        }
                    }
                }
                else
                    dataSource.values[0].measures = [];
                return reportItem[0];
            },

            getReportItemByFieldName: function (fieldName, dataSource) {
                var axis = "columns";
                var reportItem = $.grep(dataSource.columns, function (value) {
                    return value.fieldName.toLowerCase() == fieldName.toLowerCase();
                });
                if (reportItem.length == 0) {
                    reportItem = $.grep(dataSource.rows, function (value) {
                        return value.fieldName.toLowerCase() == fieldName.toLowerCase()
                    });
                    axis = "rows";
                }
                if (reportItem.length == 0) {
                    var valuesItems = dataSource.cube == "" ? dataSource.values : (dataSource.values.length > 0 && !ej.isNullOrUndefined(dataSource.values[0].measures)) ? dataSource.values[0].measures : [];
                    reportItem = $.grep(valuesItems, function (value) {
                        return value.fieldName.toLowerCase() == fieldName.toLowerCase();
                    });
                    axis = "values"
                }
                if (reportItem.length == 0) {
                    reportItem = $.grep(dataSource.filters, function (value) {
                        return (value.fieldName.toLowerCase() == fieldName.toLowerCase());
                    });
                    axis = "filters"
                }
                return {item: reportItem[0], axis: axis};
            },

            getReportItemByFieldCaption: function (fieldCaption, dataSource) {
                var axis = "columns";
                var reportItem = $.grep(dataSource.columns, function (value) {
                    return value.fieldCaption.toLowerCase() == fieldCaption.toLowerCase();
                });
                if (reportItem.length == 0) {
                    reportItem = $.grep(dataSource.rows, function (value) {
                        return value.fieldCaption.toLowerCase() == fieldCaption.toLowerCase()
                    });
                    axis = "rows";
                }
                if (reportItem.length == 0) {
                    var valuesItems = dataSource.cube == "" ? dataSource.values : (dataSource.values.length > 0 && !ej.isNullOrUndefined(dataSource.values[0].measures)) ? dataSource.values[0].measures : [];
                    reportItem = $.grep(valuesItems, function (value) {
                        return value.fieldCaption.toLowerCase() == fieldCaption.toLowerCase();
                    });
                    axis = "values"
                }
                if (reportItem.length == 0) {
                    reportItem = $.grep(dataSource.filters, function (value) {
                        return (value.fieldCaption.toLowerCase() == fieldCaption.toLowerCase());
                    });
                    axis = "filters"
                }
                return {item: reportItem[0], axis: axis};
            },

            //Common functionalities

            closePreventPanel: function (args) {
                var ctrlObj = args.type != 'close' ? args : this;
                ctrlObj.element.find("#preventDiv").remove();
                if (!ej.isNullOrUndefined(ctrlObj.model.pivotControl)) ctrlObj.model.pivotControl.element.find("#preventDiv").remove();
                if (!ej.isNullOrUndefined(ctrlObj._waitingPopup))
                    ctrlObj._waitingPopup.hide();
                if (!ej.isNullOrUndefined(ctrlObj.model.pivotControl) && !ej.isNullOrUndefined(ctrlObj.model.pivotControl._waitingPopup))
                    ctrlObj.model.pivotControl._waitingPopup.hide();
            },

            openPreventPanel: function (controlObj) {
                var backgroundDiv = ej.buildTag("div#preventDiv.errorDlg").css({
                    "width": $('body').width() + "px",
                    "height": $('body').height() + "px",
                    "position": "absolute",
                    "top": $('body').offset().top + "px",
                    "left": $('body').offset().left + "px",
                    "z-index": 10
                })[0].outerHTML;
                $('#' + controlObj._id).append(backgroundDiv);
            },

            _createErrorDialog: function (args, action, obj) {
                ej.Pivot.closePreventPanel(obj);
                obj._errorDialog = action;
                ej.Pivot.openPreventPanel(obj);
                if (obj.element.find(".errorDialog:visible").length == 0) {
                    if (!ej.isNullOrUndefined(args.Exception))
                        var dialogElem = ej.buildTag("div.errorDialog#ErrorDialog", ej.buildTag("div.warningImg")[0].outerHTML + ej.buildTag("div.warningContent action:", (args.Exception.Message))[0].outerHTML + ej.buildTag("br")[0].outerHTML + ej.buildTag("div." + obj._id + "stackTraceContent", "Stack Trace :" + args.Exception.StackTraceString)[0].outerHTML + ej.buildTag("div", ej.buildTag("button#ErrOKBtn.errOKBtn", "OK", {"margin": "20px 0 10px 165px"})[0].outerHTML)[0].outerHTML).attr("title", action)[0].outerHTML;
                    else
                        var dialogElem = ej.buildTag("div.errorDialog#ErrorDialog", ej.buildTag("div.warningImg")[0].outerHTML + ej.buildTag("div.warningContent action:", (args))[0].outerHTML + ej.buildTag("div", ej.buildTag("button#ErrOKBtn.errOKBtn", "OK", {"margin": "20px 0 10px 165px"})[0].outerHTML)[0].outerHTML).attr("title", action)[0].outerHTML;
                    obj.element.append(dialogElem);
                    obj.element.find(".errorDialog").ejDialog({
                        target: "#" + obj._id,
                        enableResize: false,
                        enableRTL: obj.model.enableRTL,
                        width: "400px",
                        close: ej.proxy(ej.Pivot.closePreventPanel, obj)
                    });
                    var _errorDialog = obj.element.find(".errorDialog").data("ejDialog");
                    $("#" + _errorDialog._id + "_wrapper").css({left: "50%", top: "50%"});
                    obj.element.find(".errOKBtn").ejButton({
                        type: ej.ButtonType.Button,
                        width: "50px"
                    }).on(ej.eventType.click, function (e) {
                        if (obj._errorDialog == "nodeCheck" && !ej.isNullOrUndefined(obj._schemaData) && !ej.isNullOrUndefined(obj._schemaData._selectedTreeNode))
                            obj._schemaData._tableTreeObj.uncheckNode(obj._schemaData._selectedTreeNode);
                        obj.element.find("#preventDiv").remove();
                        if (obj._errorDialog == "Warning" || obj._errorDialog == "Exception" || obj._errorDialog == "Error")
                            obj.element.children("#ErrorDialog_wrapper").remove();
                    });
                    obj.element.find(".e-dialog .e-close").attr("title", "Close");
                    if (!ej.isNullOrUndefined($("#" + obj._id).data("ejWaitingPopup"))) {
                        $("#" + obj._id).data("ejWaitingPopup").hide();
                    }
                    if (typeof oclientWaitingPopup != 'undefined' && oclientWaitingPopup != null)
                        oclientWaitingPopup.hide();

                    if (!ej.isNullOrUndefined(args.Exception)) {
                        var showChar = 50;
                        var ellipsestext = "...";
                        var moretext = "Show more";
                        var lesstext = "Show less";
                        $('.' + obj._id + 'stackTraceContent').each(function () {
                            var content = $(this).html();
                            if (content.length > showChar) {
                                obj._id
                                var c = content.substr(0, showChar);
                                var h = content.substr(showChar, content.length - showChar);
                                var html = c + ej.buildTag("span." + obj._id + "moreellipses", ellipsestext)[0].outerHTML + ej.buildTag("span." + obj._id + "morecontent", ej.buildTag("span", h).css("display", "none")[0].outerHTML + ej.buildTag("a." + obj._id + "morelink", moretext).css("display", "block")[0].outerHTML)[0].outerHTML;
                                $(this).html(html);
                            }
                        });
                        $("." + obj._id + "morelink").click(function () {
                            if ($(this).hasClass("less")) {
                                $(this).removeClass("less");
                                $(this).html(moretext);
                            } else {
                                $(this).addClass("less");
                                $(this).html(lesstext);
                            }
                            $(this).parent().prev().toggle("slow", function () {
                            });
                            $(this).prev().toggle("slow", function () {
                            });
                            return false;
                        });
                    }
                }
            },

            _contextMenuOpen: function (args, ctrlObj) {
                ej.Pivot.openPreventPanel(ctrlObj);
                ctrlObj._selectedMember = $(args.target);
                var mode;
                var menuObj;
                if (ctrlObj.pluginName == "ejPivotGrid") {
                    mode = ctrlObj.model.analysisMode == ej.Pivot.AnalysisMode.Olap ? "olap" : "pivot";
                    menuObj = $("#pivotTree").data('ejMenu');
                }
                else {
                    if (!ej.isNullOrUndefined(ctrlObj.model.pivotControl))
                        mode = ctrlObj.model.pivotControl.model.analysisMode == ej.Pivot.AnalysisMode.Olap ? "olap" : "pivot";
                    menuObj = $("#pivotTreeContextMenu").data('ejMenu');
                }
                if (mode == ej.Pivot.AnalysisMode.Olap) {
                    if (ej.isNullOrUndefined($(args.target).parent().attr("tag"))) {
                        if ($(args.target).hasClass("pivotButton") && $(args.target).children(".pvtBtn:eq(0)").length > 0) {
                            ctrlObj._selectedMember = $(args.target).children(".pvtBtn:eq(0)");
                            return false;
                        }
                    }
                    if ($(args.target).parent().attr("tag").split(":")[1].toLowerCase().startsWith("[measures]")) {
                        menuObj.disable();
                    }
                    else if (ctrlObj._selectedMember.parent().attr("tag").split(":")[1].toLowerCase() == "measures") {
                        menuObj.disableItem(ctrlObj._getLocalizedLabels("AddToValues"));
                        menuObj.disableItem(ctrlObj._getLocalizedLabels("AddToFilter"));
                        menuObj.enableItem(ctrlObj._getLocalizedLabels("AddToRow"));
                        menuObj.enableItem(ctrlObj._getLocalizedLabels("AddToColumn"));
                    }
                    else {
                        menuObj.disableItem(ctrlObj._getLocalizedLabels("AddToValues"));
                        $(args.target.parentElement).find(".namedSetCDB").length > 0 ? menuObj.disableItem(ctrlObj._getLocalizedLabels("AddToFilter")) : menuObj.enableItem(ctrlObj._getLocalizedLabels("AddToFilter"));
                        menuObj.enableItem(ctrlObj._getLocalizedLabels("AddToRow"));
                        menuObj.enableItem(ctrlObj._getLocalizedLabels("AddToColumn"));
                    }
                }
                else if (mode == ej.Pivot.AnalysisMode.Pivot) {
                    var targetText = args.target.textContent;
                    if ($(args.target).hasClass("e-btn")) {
                        menuObj.enable();
                        if (ctrlObj.pluginName == "ejPivotGrid") {
                            menuObj.disableItem(ctrlObj._getLocalizedLabels("CalculatedField"));
                            if (($(args.target).parents(".pivotButton").attr("tag").split(":")[0]).toLowerCase() == "values") {
                                if (ctrlObj.model.operationalMode == ej.PivotGrid.OperationalMode.ClientMode && $.grep(ctrlObj.model.dataSource.values, function (value) {
                                        return value.fieldCaption == targetText && value.isCalculatedField == true;
                                    }).length > 0)
                                    menuObj.disable();
                                else if (ctrlObj.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode && $.grep(JSON.parse(ctrlObj.getOlapReport()).PivotCalculations, function (value) {
                                        return value.FieldHeader == targetText && value.CalculationType == 8;
                                    }).length > 0)
                                    menuObj.disable();
                                menuObj.enableItem(ctrlObj._getLocalizedLabels("CalculatedField"));
                            }
                        }
                    }
                    else {
                        var menuObj = $("#pivotTree").data('ejMenu');
                        menuObj.disable();
                    }
                }
            },

            _searchTreeNodes: function (args) {
                var inputObj = $(args.target).hasClass("searchTreeView") ? this.element.find(".searchTreeView").data("ejMaskEdit") : this.element.find(".searchEditorTreeView").data("ejMaskEdit");
                var treeobj = $(args.target).hasClass("searchTreeView") ? (this.model.operationalMode == ej.Pivot.OperationalMode.ClientMode || (this.model.analysisMode == ej.Pivot.AnalysisMode.Pivot && this.model.operationalMode == ej.Pivot.OperationalMode.ServerMode) ? this.element.find(".schemaFieldTree").data("ejTreeView") : this.element.find(".cubeTreeView").data("ejTreeView")) : this.element.find(".editorTreeView").data("ejTreeView");
                var treeElement = treeobj.element;
                var searchVal = !ej.isNullOrUndefined(inputObj.get_StrippedValue()) ? inputObj.get_StrippedValue().toLowerCase() : "";

                if (searchVal.length > 0) {
                    var matchedNode = [], otherNodes = [];
                    var linkNodes = treeElement.find('ul>li>div>a');
                    for (var p = 0; p < linkNodes.length; p++) {
                        if ($(linkNodes[p]).text().toLowerCase().indexOf(searchVal) != -1)
                            matchedNode.push(linkNodes[p]);
                        else
                            otherNodes.push(linkNodes[p]);
                    }
                    var resultNodes = treeElement.find(matchedNode).closest("li").css("display", "block");
                    treeElement.find(otherNodes).closest("li").css("display", "none");
                    for (var i = 0; i < resultNodes.length; i++) {
                        var currentNode = $(resultNodes[i]);
                        var parentNode = currentNode.parents('ul').closest('li').css("display", "block");
                        if (parentNode.length > 0) {
                            treeobj.expandNode(parentNode);
                            if (treeobj.model.expandedNodes.indexOf($(treeobj._liList).index(parentNode)) == -1 && !ej.isNullOrUndefined(window._temp))
                                window._temp.push(parentNode);
                        }
                        var childrenUl = currentNode.children('ul');
                        if (childrenUl.length > 0 && childrenUl.children('li:visible').length == 0) {
                            currentNode.children('ul').children('li').css("display", "block");
                            treeobj.expandNode(resultNodes[i]);
                            if (treeobj.model.expandedNodes.indexOf($(treeobj._liList).index(resultNodes[i])) == -1 && !ej.isNullOrUndefined(window._temp))
                                window._temp.push(resultNodes[i]);
                        }
                    }
                }
                else {
                    treeElement.find('ul>li').css("display", "block");
                    if (!ej.isNullOrUndefined(window._temp))
                        for (var i = 0; i < window._temp.length; i++) {
                            treeobj._collpaseNode(window._temp[i]);
                        }
                    window._temp = [];
                    if ($(args.target).hasClass("searchTreeView"))
                        treeobj.collapseAll();
                }
            },

            editorTreeNavigatee: function (args, me) {
                var currentPage = me._memberPageSettings.currentMemeberPage;
                if (!$(args.target).hasClass("pageDisabled")) {
                    if ($(args.target).hasClass("nextPage")) {
                        me._memberPageSettings.startPage += me.model.memberEditorPageSize;
                        me._memberPageSettings.currentMemeberPage += 1;
                        me._memberPageSettings.endPage += me.model.memberEditorPageSize;
                    }
                    else if ($(args.target).hasClass("prevPage")) {
                        me._memberPageSettings.currentMemeberPage -= 1;
                        me._memberPageSettings.startPage = Math.abs(me._memberPageSettings.startPage - (me._memberPageSettings.currentMemeberPage == 1 ? me.model.memberEditorPageSize : me.model.memberEditorPageSize));
                        me._memberPageSettings.endPage -= me.model.memberEditorPageSize;
                    }
                    else if ($(args.target).hasClass("firstPage")) {
                        me._memberPageSettings.currentMemeberPage = 1;
                        me._memberPageSettings.endPage = me.model.memberEditorPageSize;
                        me._memberPageSettings.startPage = 0;
                    }
                    else if ($(args.target).hasClass("lastPage")) {
                        me._memberPageSettings.currentMemeberPage = parseInt(me.element.find(".memberPageCount").text().split("/")[1].trim());
                        me._memberPageSettings.endPage = (me._memberPageSettings.currentMemeberPage * me.model.memberEditorPageSize);
                        me._memberPageSettings.startPage = (me._memberPageSettings.endPage - me.model.memberEditorPageSize);
                    }
                    else {
                        if (parseInt($(args.target).val()) > parseInt((!ej.isNullOrUndefined(me._pivotSchemaDesigner) ? me._pivotSchemaDesigner.element.find(".memberPageCount").text().split("/")[1].trim() : me.element.find(".memberPageCount").text().split("/")[1].trim())) || parseInt($(args.target).val()) == 0)
                            return false
                        else {
                            me._memberPageSettings.currentMemeberPage = parseInt($(args.target).val());
                            me._memberPageSettings.endPage = me._memberPageSettings.currentMemeberPage * me.model.memberEditorPageSize;
                            me._memberPageSettings.startPage = me._memberPageSettings.currentMemeberPage == 1 || me._memberPageSettings.currentMemeberPage == 0 ? 0 : (me._memberPageSettings.endPage - me.model.memberEditorPageSize);
                        }
                    }
                    me._waitingPopup.show();
                    if (me.model.operationalMode == ej.Pivot.OperationalMode.ClientMode) {
                        me._isMemberPageFilter = true;
                        var memberTreeObj = ej.Pivot.updateTreeView(me._pivotSchemaDesigner);
                        var treeData = ej.DataManager(me._editorTreeData).executeLocal(ej.Query().where("pid", "equal", null || undefined).page(me._memberPageSettings.currentMemeberPage, me.model.memberEditorPageSize));
                        treeData.splice(0, 0, {id: "All", name: "All", checkedStatus: me._isAllMemberChecked, tag: ""});
                        me._pivotSchemaDesigner._fetchMemberSuccess({EditorTreeInfo: JSON.stringify(treeData)});
                    }
                    else {
                        me._isSearchApplied = false;
                        this.editorTreePageInfoSuccess(me._editorTreeData, me);
                    }
                }
            },

            editorTreePageInfoSuccess: function (editorTree, me) {
                setTimeout(function () {
                    me._memberPageSettings.currentMemeberPage > 1 ? me.element.find(".prevPage, .firstPage").removeClass("pageDisabled").addClass("pageEnabled") : me.element.find(".prevPage, .firstPage").removeClass("pageEnabled").addClass("pageDisabled");
                    me._memberPageSettings.currentMemeberPage == parseInt(me.element.find(".memberPageCount").text().split("/")[1].trim()) ? me.element.find(".nextPage, .lastPage").removeClass("pageEnabled").addClass("pageDisabled") : me.element.find(".nextPage, .lastPage").removeClass("pageDisabled").addClass("pageEnabled");
                    var editorTreeInfo, treeViewData;
                    if (me.model.operationalMode == ej.Pivot.OperationalMode.ClientMode) {
                        if (editorTree[0] != undefined)
                            editorTreeInfo = editorTree[0].Value;
                        else if (editorTree.d != undefined)
                            editorTreeInfo = editorTree.d[0].Value;
                        else
                            editorTreeInfo = editorTree.EditorTreeInfo;
                        treeViewData = $.parseJSON(editorTreeInfo);
                        treeViewData.splice(-1, 1);
                    }
                    me.element.find(".memberCurrentPage").val(me._memberPageSettings.currentMemeberPage);
                    me._appendTreeViewData(me.model.operationalMode == ej.Pivot.OperationalMode.ClientMode ? treeViewData : ej.DataManager(me._editorTreeData).executeLocal(ej.Query().where("pid", "equal", null || undefined).page(me._memberPageSettings.currentMemeberPage, me.model.memberEditorPageSize)), false);
                    me._unWireEvents();
                    me._wireEvents();
                    me._waitingPopup.hide();
                }, 0);
            },

            _searchEditorTreeNodes: function (args, ctrlObj) {
                ctrlObj._waitingPopup.show();
                var _this = this;
                setTimeout(function () {
                    var searchVal = "";
                    if (ej.isNullOrUndefined(ctrlObj._pivotSchemaDesigner))
                        searchVal = !ej.isNullOrUndefined($.trim(ctrlObj.element.find(".searchEditorTreeView").val())) ? $.trim(ctrlObj.element.find(".searchEditorTreeView").val()).toLowerCase() : "";
                    else
                        searchVal = !ej.isNullOrUndefined($.trim(ctrlObj._pivotSchemaDesigner.element.find(".searchEditorTreeView").val())) ? $.trim(ctrlObj._pivotSchemaDesigner.element.find(".searchEditorTreeView").val()).toLowerCase() : "";
                    if (searchVal != "") {
                        var searchTreeNodes = jQuery.extend(true, [], ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("name", "contains", searchVal, true)));
                        var childNodes = jQuery.extend(true, [], ej.DataManager(searchTreeNodes).executeLocal(ej.Query().where("pid", "notEqual", null || undefined).where("name", "contains", searchVal, true)));
                        //searchTreeNodes = [];
                        for (var i = 0; i < childNodes.length; i++) {
                            //childNodes[i].expanded = false;
                            _this._appendParentNodes(searchTreeNodes, childNodes[i], ctrlObj);
                        }
                        ctrlObj._isSearchApplied = true;
                        if (ej.isNullOrUndefined(ctrlObj._pivotSchemaDesigner))
                            ctrlObj._appendTreeViewData(searchTreeNodes, false);
                        else {
                            if (searchTreeNodes.length > 0)
                                searchTreeNodes.splice(0, 0, {
                                    id: "All",
                                    name: "All",
                                    checkedStatus: ctrlObj._isAllMemberChecked,
                                    tag: ""
                                });
                            _this._createSearchTreeview(searchTreeNodes, ctrlObj._pivotSchemaDesigner);
                        }

                        //ctrlObj._memberTreeObj.expandAll(null, true);
                        //me._appendTreeViewData(ej.DataManager(me._editorTreeData).executeLocal(ej.Query().where("name", "contains", searchVal, true)), false);
                    }
                    else {
                        ctrlObj._isSearchApplied = false;
                        if (ej.isNullOrUndefined(ctrlObj._pivotSchemaDesigner))
                            ctrlObj._appendTreeViewData(ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", null || undefined).page(ctrlObj._memberPageSettings.currentMemeberPage, ctrlObj.model.memberEditorPageSize)), false);
                        else {
                            var searchTreeNodes = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", null || undefined).page(ctrlObj._memberPageSettings.currentMemeberPage, ctrlObj.model.memberEditorPageSize));
                            searchTreeNodes.splice(0, 0, {
                                id: "All",
                                name: "All",
                                checkedStatus: ctrlObj._isAllMemberChecked,
                                tag: ""
                            });
                            _this._createSearchTreeview(searchTreeNodes, ctrlObj._pivotSchemaDesigner);
                        }
                    }
                    if (ej.isNullOrUndefined(ctrlObj._pivotSchemaDesigner)) {
                        ctrlObj._unWireEvents();
                        ctrlObj._wireEvents();
                    }
                    ctrlObj._waitingPopup.hide();
                }, 0);
            },
            _createSearchTreeview: function (searchTreeNodes, ctrlObj) {
                ctrlObj.element.find(".editorTreeView").ejTreeView({
                    showCheckbox: true,
                    loadOnDemand: true,
                    enableRTL: ctrlObj.model.enableRTL,
                    beforeDelete: function () {
                        return false;
                    },
                    height: ctrlObj.element.find(".memberEditorDiv").height(),
                    fields: {
                        id: "id",
                        text: "name",
                        isChecked: "checkedStatus",
                        hasChild: "hasChildren",
                        dataSource: searchTreeNodes
                    },
                });
                var treeViewElements = ctrlObj.element.find(".editorTreeView").find("li");
                for (var i = 0; i < treeViewElements.length; i++) {
                    if (!ej.isNullOrUndefined($(treeViewElements[i]).attr("id")))
                        $(treeViewElements[i]).attr("tag", ej.DataManager(searchTreeNodes).executeLocal(ej.Query().where("id", "equal", $(treeViewElements[i]).attr("id")))[0].tag);
                }
                ctrlObj._memberTreeObj = ctrlObj.element.find(".editorTreeView").data("ejTreeView");
                ctrlObj._memberTreeObj.model.nodeCheck = ej.proxy(ctrlObj._nodeCheckChanges, ctrlObj);
                ctrlObj._memberTreeObj.model.nodeUncheck = ej.proxy(ctrlObj._nodeCheckChanges, ctrlObj);
                ctrlObj._memberTreeObj.model.beforeExpand = ej.proxy(ctrlObj._beforeNodeExpand, ctrlObj);
                if (!ej.isNullOrUndefined(ctrlObj.element.find(".e-dialog .e-text:visible").first())) {
                    if (ctrlObj.element.find(".e-dialog .e-text:visible").length > 0) {
                        ctrlObj.element.find(".e-dialog .e-text:visible").first().attr("tabindex", "-1").focus().addClass("hoverCell");
                        ctrlObj.element.find(".e-dialog button").removeClass("hoverCell");
                    }
                    else
                        ctrlObj.element.find(".e-dialog button:visible").first().attr("tabindex", "-1").focus().addClass("hoverCell");
                }
            },
            _appendParentNodes: function (searchTreeNodes, childNode, ctrlObj) {
                var parentNode = jQuery.extend(true, [], ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("id", "equal", childNode.pid)));
                if (!ej.isNullOrUndefined(parentNode) && parentNode.length > 0 && ej.DataManager(searchTreeNodes).executeLocal(ej.Query().where("id", "equal", parentNode[0].id)).length == 0) {
                    parentNode[0].expanded = true;
                    searchTreeNodes.push(parentNode[0]);
                    if (!ej.isNullOrUndefined(parentNode[0].pid))
                        this._appendParentNodes(searchTreeNodes, parentNode[0], ctrlObj);
                }
            },
            _selectParentTreeNode: function (node, ctrlObj) {
                var parentItem = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("id", "equal", node.pid));
                if (!ej.isNullOrUndefined(parentItem) && parentItem.length > 0) {
                    parentItem[0].checkedStatus = true;
                    this._selectParentTreeNode(parentItem[0], ctrlObj);
                }
            },
            _selectChildTreeNode: function (node, ctrlObj) {
                var childNodeItem = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", node.id));
                if (!ej.isNullOrUndefined(childNodeItem) && childNodeItem.length > 0) {
                    for (var i = 0; i < childNodeItem.length; i++) {
                        childNodeItem[i].checkedStatus = true;
                        this._selectChildTreeNode(childNodeItem[i], ctrlObj);
                    }
                }
            },
            _unSelectChildTreeNode: function (node, ctrlObj) {
                var childNodeItem = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", node.id));
                if (!ej.isNullOrUndefined(childNodeItem) && childNodeItem.length > 0) {
                    for (var i = 0; i < childNodeItem.length; i++) {
                        childNodeItem[i].checkedStatus = false;
                        this._selectChildTreeNode(childNodeItem[i], ctrlObj);
                    }
                }
            },
            _unSelectParentTreeNode: function (node, ctrlObj) {
                var parentItem = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("id", "equal", node.pid));
                if (!ej.isNullOrUndefined(parentItem) && parentItem.length > 0) {
                    parentItem[0].checkedStatus = false;
                    if (ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", parentItem[0].pid).where("checkedStatus", "equal", true)).length == 0)
                        this._unSelectParentTreeNode(parentItem[0], ctrlObj);
                }
            },
            _getSelectedTreeState: function (isSlicer, ctrlObj) {
                if (isSlicer) {
                    var selectedNodes = new Array();
                    var firstLevelNodes = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", null || undefined));
                    for (var i = 0; i < firstLevelNodes.length; i++) {
                        var nodeExpanded = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", firstLevelNodes[i].id));
                        var nodeInfo = {
                            caption: firstLevelNodes[i].name,
                            parentId: ej.isNullOrUndefined(firstLevelNodes[i].pid) ? "None" : firstLevelNodes[i].pid,
                            id: firstLevelNodes[i].id,
                            checked: firstLevelNodes[i].checkedStatus,
                            expanded: nodeExpanded.length > 0 ? true : false,
                            childNodes: new Array(),
                            tag: firstLevelNodes[i].tag
                        };
                        if (nodeExpanded.length > 0) {
                            for (var j = 0; j < nodeExpanded.length; j++) {
                                nodeInfo.childNodes.push(this._getEditorSlicerInfo(nodeExpanded[j], ctrlObj));
                            }
                        }
                        selectedNodes.push(nodeInfo);
                    }
                    return JSON.stringify(selectedNodes);
                }
                else {
                    var selectedNodes = "";
                    for (var i = 0; i < ctrlObj._editorTreeData.length; i++) {
                        if (ctrlObj._editorTreeData[i].checkedStatus == true)
                            selectedNodes += "::" + ctrlObj._editorTreeData[i].id + "||" + ctrlObj._editorTreeData[i].tag;
                    }
                    return selectedNodes;
                }
            },
            _getUnSelectedTreeState: function (ctrlObj) {
                var unSelectedNodes = "";
                for (var i = 0; i < ctrlObj._editorTreeData.length; i++) {
                    if (ctrlObj._editorTreeData[i].checkedStatus == false)
                        unSelectedNodes += "::" + ctrlObj._editorTreeData[i].id + "||" + ctrlObj._editorTreeData[i].tag;
                }
                return unSelectedNodes;
            },
            _getEditorSlicerInfo: function (node, ctrlObj) {
                var nodeExpanded = ej.DataManager(ctrlObj._editorTreeData).executeLocal(ej.Query().where("pid", "equal", node.id));
                var childNode = {
                    caption: node.name,
                    parentId: ej.isNullOrUndefined(node.pid) ? "None" : node.pid,
                    id: node.id,
                    checked: node.checkedStatus,
                    expanded: nodeExpanded.length > 0 ? true : false,
                    childNodes: new Array(),
                    tag: node.tag
                };
                if (nodeExpanded.length > 0) {
                    for (var j = 0; j < nodeExpanded.length; j++) {
                        childNode.childNodes.push(this._getEditorSlicerInfo(nodeExpanded[j], ctrlObj));
                    }
                }
                return childNode;
            },
            createErrorDialog: function (controlObj) {
                ej.Pivot.openPreventPanel(controlObj);
                var dialogObj;
                if (controlObj.element.find(".errorDialog").length == 0) {
                    var dialogElem = ej.buildTag("div.errorDialog#ErrorDialog", ej.buildTag("div.warningImg")[0].outerHTML + ej.buildTag("div.warningContent", controlObj._getLocalizedLabels("AlertMsg"))[0].outerHTML + ej.buildTag("div", ej.buildTag("button#ErrOKBtn.errOKBtn", "OK")[0].outerHTML)[0].outerHTML).attr("title", controlObj._getLocalizedLabels("Warning"))[0].outerHTML;
                    controlObj.element.append(dialogElem);
                    controlObj.element.find(".errorDialog").ejDialog({
                        target: "#" + controlObj._id,
                        enableResize: false,
                        enableRTL: controlObj.model.enableRTL,
                        width: "400px"
                    });
                    dialogObj = controlObj.element.find(".errorDialog").data("ejDialog");
                    $("#" + dialogObj._id + "_wrapper").css({left: "50%", top: "50%"});
                    controlObj.element.find(".errOKBtn").ejButton({
                        type: ej.ButtonType.Button,
                        click: ej.proxy(ej.Pivot.errOKBtnClick, controlObj)
                    });
                    controlObj.element.find(".e-dialog .e-close").attr("title", controlObj._getLocalizedLabels("Close"));
                }
                else {
                    dialogObj = controlObj.element.find(".errorDialog").data("ejDialog");
                    dialogObj.open();
                }
            },

            errOKBtnClick: function (args) {
                this.element.find("#preventDiv").remove();
                var dialogObj = this.element.find(".errorDialog").data("ejDialog");
                dialogObj._ejDialog.find("div.e-dialog-icon").trigger("click");
            },

            //OLAP functionalities
            doAjaxPost: function (type, url, data, onSuccess, onComplete, customArgs) {
                var contentType, dataType, successEvt, isAsync = true;
                if ((data["XMLA"] == undefined))
                    contentType = 'application/json; charset=utf-8', dataType = 'json', successEvt = $.proxy(onSuccess, this);
                else
                    contentType = 'text/xml', dataType = 'xml', data = data["XMLA"], successEvt = $.proxy(onSuccess, ej.olap.base, customArgs), isAsync = ((ej.browserInfo().name == "msie" && ej.browserInfo().version <= 9) ? false : (!ej.isNullOrUndefined(customArgs) && customArgs["action"] != "loadFieldElements") ? true : false);
                $.ajax({
                    type: type,
                    url: url,
                    contentType: contentType,
                    async: isAsync,
                    dataType: dataType,
                    data: data,
                    success: successEvt,
                    complete: ej.proxy(function (onComplete) {
                        $.proxy(onComplete, this);
                        var eventArgs = {"action": this._currentAction, "customObject": "", element: this.element};
                    }, this),
                    error: ej.proxy(function (msg, textStatus, errorThrown) {
                        if (typeof this._ogridWaitingPopup != 'undefined' && this._ogridWaitingPopup != null)
                            this._ogridWaitingPopup.hide();
                        if (typeof oclientWaitingPopup != 'undefined' && oclientWaitingPopup != null)
                            oclientWaitingPopup.hide();
                        var eventArgs = {
                            "action": this._drillAction != "" ? this._drillAction : "initialize",
                            "customObject": "",
                            "element": this.element,
                            "Message": msg
                        };
                        this._trigger("renderFailure", eventArgs);
                        this.renderControlFromJSON("");
                        if (this._dataModel == "XMLA")
                            this._createErrorDialog(msg.statusText, this._getLocalizedLabels("Error"));
                        msg.statusText
                    }, this)
                });
            },

            getCubeList: function (customArgs, e) {
                var cubeList = [];
                for (var i = 0; i < $(e).find("row").length; i++) {
                    var element = $($(e).find("row")[i]);
                    cubeList.push({name: $(element).children("CUBE_NAME").text()});
                }
                customArgs.pvtCtrldObj.setCubeList(cubeList);
            },

            generateTreeViewData: function (schemaObj) {
                var args = {
                    catalog: schemaObj.model.pivotControl.model.dataSource.catalog,
                    cube: schemaObj.model.pivotControl.model.dataSource.cube,
                    url: schemaObj.model.pivotControl.model.dataSource.data,
                    request: "MDSCHEMA_DIMENSIONS"
                }
                this._getTreeData(args, this.loadDimensionElements, {
                    schemaData: schemaObj,
                    action: "loadFieldElements"
                });
            },

            loadDimensionElements: function (customArgs, data) {
                var dimensionName, contObj = customArgs.schemaData.model.pivotControl, measures = {},
                    conStr = ej.olap.base._getConnectionInfo(contObj.model.dataSource.data), args = {},
                    isMon = contObj.model.dataSource.providerName == ej.olap.Providers.Mondrian;
                args = {
                    catalog: contObj.model.dataSource.catalog,
                    cube: contObj.model.dataSource.cube,
                    url: contObj.model.dataSource.data,
                    request: "MDSCHEMA_DIMENSIONS"
                };
                contObj["schemaTreeView"] = [];
                contObj["reportItemNames"] = [];

                for (var i = 0; i < $(data).find("row").length; i++) {
                    var element = $($(data).find("row")[i]),
                        dimensionUniqueName = element.find("DIMENSION_UNIQUE_NAME").text(),
                        dimensionName = element.find("DIMENSION_CAPTION").text();
                    if (dimensionUniqueName.toLowerCase().indexOf("[measure") >= 0)
                        measures = {
                            hasChildren: true,
                            isSelected: false,
                            id: dimensionUniqueName,
                            name: dimensionName,
                            spriteCssClass: dimensionUniqueName.toLowerCase() == "[measures]" ? "folderCDB e-icon" : "dimensionCDB e-icon",
                            tag: dimensionUniqueName
                        }
                    else if (!$($(data).find("row")[0]).find("HIERARCHY_CAPTION").length > 0) {
                        contObj.schemaTreeView.push({
                            hasChildren: true,
                            isSelected: false,
                            id: (isMon ? dimensionUniqueName + "~#^Dim" : dimensionUniqueName),
                            name: dimensionName,
                            spriteCssClass: "dimensionCDB e-icon",
                            tag: dimensionUniqueName,
                            defaultHierarchy: $($(data).find("row")[i]).children("DEFAULT_HIERARCHY").text()
                        });
                    }
                }
                contObj.schemaTreeView.splice(0, 0, measures);
                if (!contObj.model.enableDrillThrough || (customArgs.schemaData != undefined && customArgs.schemaData.model.olap.showNamedSets)) {
                    args.request = "MDSCHEMA_SETS";
                    ej.Pivot._getTreeData(args, ej.Pivot.loadNamedSetElements, customArgs);
                }
                else {
                    args.request = "MDSCHEMA_HIERARCHIES";
                    if (ej.isNullOrUndefined(contObj._fieldData) || (!ej.isNullOrUndefined(contObj._fieldData) && ej.isNullOrUndefined(contObj._fieldData.hierarchy)))
                        this._getFieldItemsInfo(contObj);
                    if (contObj._fieldData.hierarchySuccess == undefined)
                        ej.Pivot._getTreeData(args, contObj.loadHierarchyElements, customArgs);
                    else
                        ej.Pivot.loadHierarchyElements(customArgs, contObj._fieldData.hierarchySuccess);
                }
            },

            loadNamedSetElements: function (customArgs, data) {
                var contObj = customArgs.schemaData.model.pivotControl, args = {
                    catalog: contObj.model.dataSource.catalog,
                    cube: contObj.model.dataSource.cube,
                    url: contObj.model.dataSource.data,
                    request: "MDSCHEMA_HIERARCHIES"
                }
                var data = contObj.model.dataSource, treeNodeElement = {}, measureGroupItems = [], reportElement;

                reportElement = $.map(data.rows, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                });
                $.merge(reportElement, ($.map(data.columns, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                })));
                $.merge(reportElement, ($.map(data.filters, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                })));

                for (var i = 0; i < $(data).find("row").length; i++) {
                    var element = $($(data).find("row")[i]);
                    if ((!($.inArray(element.find("DIMENSIONS").text().split(".")[0], measureGroupItems) >= 0))) {
                        contObj.schemaTreeView.push({
                            hasChildren: true,
                            isSelected: false,
                            pid: element.find("DIMENSIONS").text().split(".")[0],
                            id: element.find("SET_DISPLAY_FOLDER").text() + "_" + element.find("DIMENSIONS").text().split(".")[0],
                            name: element.find("SET_DISPLAY_FOLDER").text(),
                            spriteCssClass: "folderCDB e-icon namedSets"
                        });
                        measureGroupItems.push(element.find("DIMENSIONS").text().split(".")[0]);
                    }
                    contObj.schemaTreeView.push({
                        hasChildren: true,
                        isSelected: ($.inArray("[" + $.trim(element.children("SET_NAME").text()) + "]", reportElement) >= 0),
                        pid: element.find("SET_DISPLAY_FOLDER").text() + "_" + element.find("DIMENSIONS").text().split(".")[0],
                        id: "[" + $.trim(element.children("SET_NAME").text()).replace(/\&/g, "&amp;") + "]",
                        name: element.children("SET_CAPTION").text(),
                        spriteCssClass: "namedSetCDB e-icon",
                        tag: element.find("EXPRESSION").text()
                    });
                }

                if (ej.isNullOrUndefined(contObj._fieldData) || contObj._fieldData.hierarchySuccess == undefined)
                    ej.Pivot._getTreeData(args, ej.Pivot.loadHierarchyElements, customArgs);
                else
                    ej.Pivot.loadHierarchyElements(customArgs, contObj._fieldData.hierarchySuccess);
            },

            loadHierarchyElements: function (customArgs, data) {
                var contObj = customArgs.schemaData.model.pivotControl, args = {
                    catalog: contObj.model.dataSource.catalog,
                    cube: contObj.model.dataSource.cube,
                    url: contObj.model.dataSource.data,
                    request: "MDSCHEMA_LEVELS"
                };
                var reportInfo = contObj.model.dataSource, displayFolder = "", reportElement,
                    isMon = contObj.model.dataSource.providerName == ej.olap.Providers.Mondrian;

                reportElement = $.map(reportInfo.rows, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                });
                $.merge(reportElement, ($.map(reportInfo.columns, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                })));
                $.merge(reportElement, ($.map(reportInfo.filters, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                })));

                for (var i = 0; i < $(data).find("row").length; i++) {
                    var element = $($(data).find("row")[i]),
                        dimensionUniqueName = element.find("DIMENSION_UNIQUE_NAME").text(),
                        hierarchyUniqueName = element.find("HIERARCHY_UNIQUE_NAME").text();
                    var currElement = $(contObj.schemaTreeView).filter(function (i, x) {
                        return (x.tag == dimensionUniqueName);
                    }).map(function (i, x) {
                        return x
                    });
                    if (currElement.length > 0 && (dimensionUniqueName != hierarchyUniqueName || isMon))
                        contObj.schemaTreeView.push({
                            hasChildren: true,
                            isSelected: ($.inArray(hierarchyUniqueName, reportElement) >= 0),
                            pid: dimensionUniqueName + (isMon ? "~#^Dim" : ""),
                            id: hierarchyUniqueName,
                            name: element.find("HIERARCHY_CAPTION").text(),
                            spriteCssClass: ((element.find("HIERARCHY_ORIGIN").text() != "2") && element.find("HIERARCHY_ORIGIN").text() != "6") ? "hierarchyCDB e-icon" : "attributeCDB e-icon",
                            tag: hierarchyUniqueName,
                        });
                }
                ej.Pivot._getTreeData(args, ej.Pivot.loadLevelElements, customArgs);
            },

            loadLevelElements: function (customArgs, data) {
                var contObj = customArgs.schemaData.model.pivotControl,
                    newDataSource = $.map($(data).find("row"), function (obj, index) {
                        if (parseInt($(obj).children("LEVEL_TYPE").text()) != "1" && $(obj).children("HIERARCHY_UNIQUE_NAME").text().toLowerCase() != "[measures]")
                            return {
                                hasChildren: false,
                                isChecked: false,
                                id: $(obj).find("LEVEL_UNIQUE_NAME").text(),
                                pid: $(obj).find("HIERARCHY_UNIQUE_NAME").text(),
                                name: $(obj).find("LEVEL_CAPTION").text(),
                                tag: $(obj).find("LEVEL_UNIQUE_NAME").text(),
                                spriteCssClass: "level" + parseInt($(obj).children("LEVEL_NUMBER").text()) + " e-icon"
                            };
                    });
                $.merge(contObj.schemaTreeView, newDataSource);
                if (!contObj.model.enableDrillThrough || contObj._fieldData.measureSuccess) {
                    if (ej.isNullOrUndefined(contObj._fieldData) || !contObj._fieldData.measureSuccess) {
                        var args = {
                            catalog: contObj.model.dataSource.catalog,
                            cube: contObj.model.dataSource.cube,
                            url: contObj.model.dataSource.data,
                            request: "MDSCHEMA_MEASURES"
                        }
                        ej.Pivot._getTreeData(args, ej.Pivot.loadMeasureElements, customArgs);
                    }
                    else
                        ej.Pivot.loadMeasureElements(customArgs, contObj._fieldData.measureSuccess);
                }
            },

            loadMeasureGroups: function (customArgs, data) {
                if (ej.isNullOrUndefined(customArgs.pivotControl._fieldData))
                    customArgs.pivotControl._fieldData = {};
                customArgs.pivotControl._fieldData["measuresGroups"] = $(data).find("row");
            },

            loadMeasureElements: function (customArgs, data) {
                var contObj = customArgs.schemaData.model.pivotControl, args = {
                    catalog: contObj.model.dataSource.catalog,
                    cube: contObj.model.dataSource.cube,
                    url: contObj.model.dataSource.data,
                    request: "MDSCHEMA_DIMENSIONS"
                }
                var elements = [], measureGroupItems = [], measureGroup = "", caption;

                elements = $.map(contObj.model.dataSource.values, function (obj, index) {
                    if (obj["measures"] != undefined) return obj["measures"]
                });
                contObj.reportItemNames = $.map(elements, function (obj, index) {
                    if (obj.fieldName != undefined) return obj.fieldName
                });

                if (contObj.model.locale != "en-US") {
                    var args = {
                        catalog: contObj.model.dataSource.catalog,
                        cube: contObj.model.dataSource.cube,
                        url: contObj.model.dataSource.data,
                        request: "MDSCHEMA_MEASUREGROUPS"
                    }
                    ej.Pivot._getTreeData(args, ej.Pivot.loadMeasureGroups, {
                        pivotControl: contObj,
                        action: "loadFieldElements"
                    });
                }

                for (var i = 0; i < $(data).find("row").length; i++) {
                    var element = $($(data).find("row")[i]),
                        measureGRPName = element.children("MEASUREGROUP_NAME").text(),
                        measureUQName = element.find("MEASURE_UNIQUE_NAME").text();
                    if ((!($.inArray(measureGRPName, measureGroupItems) >= 0))) {
                        if (contObj.model.locale != "en-US") {
                            var measureInfo = $.map(contObj._fieldData["measuresGroups"], function (item) {
                                if ($(item).children("MEASUREGROUP_NAME").text() == measureGRPName) return $(item).children("MEASUREGROUP_CAPTION").text()
                            });
                            caption = measureInfo.length > 0 ? measureInfo[0] : measureGRPName
                        }
                        else
                            caption = measureGRPName;
                        if (measureGRPName != "")
                            contObj.schemaTreeView.push({
                                hasChildren: true,
                                isChecked: false,
                                pid: "[Measures]",
                                id: measureGRPName,
                                name: caption,
                                spriteCssClass: "measureGroupCDB e-icon",
                                tag: measureGRPName
                            });
                        measureGroupItems.push(measureGRPName);
                    }
                    contObj.schemaTreeView.push({
                        hasChildren: true,
                        isSelected: ($.inArray(measureUQName, contObj.reportItemNames) >= 0),
                        id: measureUQName,
                        pid: measureGRPName == "" ? "[Measures]" : measureGRPName,
                        name: element.children("MEASURE_CAPTION").text(),
                        spriteCssClass: "measure",
                        tag: measureUQName
                    });
                    if (($.inArray(measureUQName, contObj.reportItemNames) >= 0))
                        contObj.reportItemNames.splice(contObj.reportItemNames.indexOf(measureUQName), 1);
                }

                if (!ej.isNullOrUndefined(customArgs.schemaData) && customArgs.schemaData.model.olap.showKpi) {
                    treeNodeElement = {
                        hasChildren: true,
                        isChecked: false,
                        id: "folderStruct",
                        name: "KPI",
                        spriteCssClass: "KPICDB folderCDB e-icon",
                        tag: ""
                    }
                    contObj.schemaTreeView.splice(1, 0, treeNodeElement);
                    args.request = "MDSCHEMA_KPIS";
                    contObj._getTreeData(args, contObj.loadKPIElements, customArgs);
                }
                else if (!ej.isNullOrUndefined(customArgs.schemaData))
                    customArgs.schemaData._createTreeView(this, contObj.schemaTreeView);
            },

            loadKPIElements: function (customArgs, data) {
                var contObj = customArgs.schemaData.model.pivotControl, data = contObj.model.dataSource,
                    reportElement = this.reportItemNames, measureGroupItems = [], measureGroup = "";

                for (var i = 0; i < $(data).find("row").length; i++) {
                    var element = $($(data).find("row")[i]), kpiName = element.children("KPI_CAPTION").text(),
                        kpiGoal = element.children("KPI_goal").text(),
                        kpiStatus = element.children("KPI_STATUS").text(),
                        kpiTrend = element.children("KPI_TREND").text(), kpiValue = element.find("KPI_VALUE").text();
                    if ((!($.inArray(element.children("KPI_NAME").text(), measureGroupItems) >= 0))) {
                        treeNodeElement = {
                            hasChildren: true,
                            isChecked: false,
                            pid: "folderStruct",
                            id: kpiName,
                            name: kpiName,
                            spriteCssClass: "measureGroupCDB e-icon",
                            tag: kpiName
                        }
                        contObj.schemaTreeView.push(treeNodeElement);
                        measureGroupItems.push(kpiName);
                    }
                    treeNodeElement = {
                        hasChildren: true,
                        isSelected: ($.inArray(kpiGoal, reportElement) >= 0),
                        id: kpiGoal,
                        pid: kpiName,
                        name: contObj._getLocalizedLabels("Goal"),
                        spriteCssClass: "kpiGoal e-icon",
                        tag: kpiGoal
                    };
                    contObj.schemaTreeView.push(treeNodeElement);
                    treeNodeElement = {
                        hasChildren: true,
                        isSelected: ($.inArray(kpiStatus, reportElement) >= 0),
                        id: kpiStatus,
                        pid: kpiName,
                        name: contObj._getLocalizedLabels("Status"),
                        spriteCssClass: "kpiStatus e-icon",
                        tag: kpiStatus
                    };
                    contObj.schemaTreeView.push(treeNodeElement);
                    treeNodeElement = {
                        hasChildren: true,
                        isSelected: ($.inArray(kpiTrend, reportElement) >= 0),
                        id: kpiTrend,
                        pid: kpiName,
                        name: contObj._getLocalizedLabels("Trend"),
                        spriteCssClass: "kpiTrend e-icon",
                        tag: kpiTrend
                    };
                    contObj.schemaTreeView.push(treeNodeElement);
                    treeNodeElement = {
                        hasChildren: true,
                        isSelected: ($.inArray(kpiValue, reportElement) >= 0),
                        id: kpiValue,
                        pid: kpiName,
                        name: contObj._getLocalizedLabels("Value"),
                        spriteCssClass: "kpiValue e-icon",
                        tag: kpiValue
                    };
                    contObj.schemaTreeView.push(treeNodeElement);
                }
                customArgs.schemaData._createTreeView(this, contObj.schemaTreeView);
                delete contObj.reportItemNames;
                delete contObj.schemaTreeView;
            },
            _createCalcMemberDialog: function (calcMemberTree) {
                var calcMemberTreeData = "";
                if (calcMemberTree.length > 1 && calcMemberTree[0] != undefined)
                    calcMemberTreeData = JSON.parse(calcMemberTree[0].Value);
                else if (calcMemberTree.d != undefined)
                    calcMemberTreeData = JSON.parse(calcMemberTree.d[0].Value);
                else
                    calcMemberTreeData = JSON.parse(calcMemberTree.CubeTreeInfo);
                if (this.model.afterServiceInvoke != null)
                    this._trigger("afterServiceInvoke", {
                        action: "fetchCalcMemberTreeView",
                        element: this.element,
                        customObject: this.model.customObject
                    });

                ej.Pivot.openPreventPanel(this);
                this.element.find(".calcMemberDialog", ".clientDialog", ".e-dialog").remove();
                var treeviewPanel = ej.buildTag("div.cubeBrowserCalcMember", ej.buildTag("div#" + this._id + "_cubeTreeViewCalcMember.cubeTreeViewCalcMember")[0].outerHTML, {})[0].outerHTML;
                var captionFields = ej.buildTag("label.lblCaption", this._getLocalizedLabels("Caption"), {})[0].outerHTML + ej.buildTag("input#" + this._id + "_captionFieldCM.captionFieldCM", "", {}).attr("aria-label", this._getLocalizedLabels("Caption"))[0].outerHTML;
                var expressionFields = ej.buildTag("label.lblexpression", this._getLocalizedLabels("Expression"), {})[0].outerHTML + ej.buildTag("textarea#" + this._id + "_expressionFieldCM.e-textarea e-droppable expressionFieldCM" + (this.model.enableRTL ? " e-rtl" : ""), "", {}).attr("aria-label", this._getLocalizedLabels("Expression"))[0].outerHTML;
                var memberFields = ej.buildTag("label.lblmemberType", this._getLocalizedLabels("MemberType"), {})[0].outerHTML + ej.buildTag("input#" + this._id + "_memberTypeFieldCM.memberTypeFieldCM", "", {}).attr("aria-label", this._getLocalizedLabels("MemberType"))[0].outerHTML + ej.buildTag("input#" + this._id + "_dimensionFieldCM.dimensionFieldCM", "", {}).attr("aria-label", "dimension")[0].outerHTML;
                var formatFields = ej.buildTag("label.lblformat", this._getLocalizedLabels("FormatString"), {})[0].outerHTML + ej.buildTag("input#" + this._id + "_formatFieldCM.formatFieldCM", "", {}).attr("aria-label", this._getLocalizedLabels("FormatString"))[0].outerHTML + ej.buildTag("input#" + this._id + "_customFormatFieldCM.customFormatFieldCM", "", {}).attr("aria-label", "custom format")[0].outerHTML;

                var fieldPanel = ej.buildTag("div.calcMemberFieldPanel", captionFields + expressionFields + memberFields + formatFields, {})[0].outerHTML;

                var okBtn = ej.buildTag("button#" + this._id + "_btnOk.btnCalcMemberOk", this._getLocalizedLabels("OK"), {}, {name: this._getLocalizedLabels("OK")}).attr("aria-label", this._getLocalizedLabels("OK"))[0].outerHTML;
                var cancelBtn = ej.buildTag("button#" + this._id + "_btnCancel.btnCalcMemberCancel", this._getLocalizedLabels("Cancel"), {}, {name: this._getLocalizedLabels("Cancel")}).attr("aria-label", this._getLocalizedLabels("Cancel"))[0].outerHTML;
                var dialogFooter = ej.buildTag("div.calcMemberFooter", okBtn + cancelBtn, {})[0].outerHTML;

                this._calcMemberDialog = ej.buildTag("div#" + this._id + "_calcMemberDialog", treeviewPanel + fieldPanel + dialogFooter, {})[0].outerHTML;
                $(this._calcMemberDialog).appendTo("#" + this._id);
                $("#" + this._id + "_calcMemberDialog").ejDialog({
                    width: "auto",
                    title: this._getLocalizedLabels("CalculatedMember"),
                    cssClass: this.model.cssClass + " calcMemberDialog",
                    enableModal: false,
                    target: "#" + this._id,
                    enableRTL: this.model.enableRTL,
                    enableResize: false,
                    close: ej.proxy(function () {
                        ej.Pivot.closePreventPanel(this)
                    }, this),
                    beforeOpen: ej.proxy(function () {
                        this.element.find(".calcMemberDialog .e-dialog").css("display", "block");

                    }, this)
                });
                this._calcMemberDialog = this.element.find("#" + this._id + "_calcMemberDialog").data("ejDialog");
                $("#" + this._id + "_btnCancel").ejButton({
                    type: ej.ButtonType.Button,
                    width: "80px",
                    enableRTL: this.model.enableRTL,
                    click: ej.proxy(function () {
                        this._calcMemberDialog.close();
                        this._selectedCalcMember = null;
                        ej.Pivot.closePreventPanel(this);
                    }, this)
                });
                $("#" + this._id + "_btnOk").ejButton({
                    type: ej.ButtonType.Button,
                    width: "80px",
                    enableRTL: this.model.enableRTL,
                    click: ej.proxy(function () {
                        if ($.trim(this.element.find("#" + this._id + "_captionFieldCM").val()) == "" || $.trim(this.element.find("#" + this._id + "_expressionFieldCM").val()) == "") {
                            ej.Pivot._createErrorDialog(this._getLocalizedLabels("EmptyField"), this._getLocalizedLabels("Warning"), this);
                            return;
                        }
                        else if (this.element.find("#" + this._id + "_formatFieldCM").val() == "Custom" && $.trim(this.element.find("#" + this._id + "_customFormatFieldCM").val()) == "") {
                            ej.Pivot._createErrorDialog(this._getLocalizedLabels("EmptyFormat"), this._getLocalizedLabels("Warning"), this);
                            return;
                        }
                        if (ej.isNullOrUndefined(this._selectedCalcMember)) {
                            for (var i = 0; i < this._calcMembers.length; i++) {
                                if ($.trim(this.element.find("#" + this._id + "_captionFieldCM").val()).toLowerCase() == this._calcMembers[i].name.toLowerCase()) {
                                    if (confirm(this._getLocalizedLabels("Confirm")))
                                        this._selectedCalcMember = $.trim(this.element.find("#" + this._id + "_captionFieldCM").val());
                                    else
                                        return;
                                    //ej.Pivot._createErrorDialog(this._getLocalizedLabels("DuplicateCalcMeasure"), this._getLocalizedLabels("Warning"), this);
                                }
                            }
                        }
                        //this._calcMembers.push({ name: $.trim(this.element.find("#" + this._id + "_captionFieldCM").val()), expression: $.trim(this.element.find("#" + this._id + "_expressionFieldCM").val()) });
                        this._calcMemberDialog.close();
                        ej.Pivot.closePreventPanel(this);
                        //if (!ej.isNullOrUndefined(this._selectedCalcMember)) {
                        //    var liElement = this.element.find(".cubeTreeView .calcMemberCDB").parents("li").find("li");
                        //    for (var i = 0; i < liElement.length; i++) {
                        //        if ($(liElement[i]).text().toLowerCase() == this._selectedCalcMember.toLowerCase()) {
                        //            this._calcMemberTreeObj.updateText($(liElement[i]).attr("id"), $.trim(this.element.find("#" + this._id + "_captionFieldCM").val()));
                        //            if ($(liElement[i]).children("div").find("> .e-text")[0] != null)
                        //                $(liElement[i]).children("div").find("> .e-text")[0].lastChild.nodeValue = $.trim(this.element.find("#" + this._id + "_captionFieldCM").val());
                        //            liElement[i].setAttribute("expression", $.trim(this.element.find("#" + this._id + "_expressionFieldCM").val()));
                        //            liElement[i].setAttribute("formatString", this.element.find("#" + this._id + "_formatFieldCM").val() == "Custom" ? $.trim(this.element.find("#" + this._id + "_customFormatFieldCM").val()) : this.element.find("#" + this._id + "_formatFieldCM").val());
                        //            liElement[i].setAttribute("nodeType", this.element.find("#" + this._id + "_memberTypeFieldCM").val() == "Measure" ? 0 : 1);
                        //        }
                        //    }
                        //    for (var i = 0; i < this._calcMembers.length; i++) {
                        //        if (this._calcMembers[i].name.toLowerCase() == this._selectedCalcMember.toLowerCase()) {
                        //            this._calcMembers[i].name = $.trim(this.element.find("#" + this._id + "_captionFieldCM").val());
                        //            this._calcMembers[i].expression = $.trim(this.element.find("#" + this._id + "_expressionFieldCM").val());
                        //            this._calcMembers[i].formatString = this.element.find("#" + this._id + "_formatFieldCM").val() == "Custom" ? $.trim(this.element.find("#" + this._id + "_customFormatFieldCM").val()) : this.element.find("#" + this._id + "_formatFieldCM").val();
                        //            this._calcMembers[i].nodeType = this.element.find("#" + this._id + "_memberTypeFieldCM").val() == "Measure" ? 0 : 1;
                        //        }
                        //    }
                        //}
                        var calcMemberTag = "";
                        if (!ej.isNullOrUndefined(this._selectedCalcMember)) {
                            var calcMember = ej.DataManager(this._calcMembers).executeLocal(ej.Query().where("name", "equal", this._selectedCalcMember, true));
                            if (!ej.isNullOrUndefined(calcMember) && calcMember.length > 0)
                                calcMemberTag = calcMember[0].tag;
                        }
                        this._selectedCalcMember = null;
                        this._waitingPopup.show();
                        var eventArgs = JSON.stringify({
                            "action": "calculatedMember",
                            "olapReport": this.currentReport,
                            "clientReports": this.reports,
                            "caption": this.currentCubeName + "%" + $.trim(this.element.find("#" + this._id + "_captionFieldCM").val()),
                            expression: $.trim(this.element.find("#" + this._id + "_expressionFieldCM").val()),
                            memberType: this.element.find("#" + this._id + "_memberTypeFieldCM").val(),
                            dimension: this.element.find("#" + this._id + "_dimensionFieldCM").val(),
                            formatString: this.element.find("#" + this._id + "_formatFieldCM").val() == "Custom" ? $.trim(this.element.find("#" + this._id + "_customFormatFieldCM").val()) : this.element.find("#" + this._id + "_formatFieldCM").val(),
                            "uniqueName": calcMemberTag,
                            "customObject": this.model.customObject
                        });
                        this.doAjaxPost("POST", this.model.url + "/" + this.model.serviceMethodSettings.calculatedMember, eventArgs, this._calcMemberDroppedSuccess);
                    }, this)
                });

                this.element.find("#" + this._id + "_cubeTreeViewCalcMember").ejTreeView({
                    fields: {
                        id: "id",
                        parentId: "pid",
                        text: "name",
                        spriteCssClass: "spriteCssClass",
                        dataSource: calcMemberTreeData
                    },
                    allowDragAndDrop: true,
                    enableRTL: this.model.enableRTL,
                    allowDropChild: false,
                    allowDropSibling: false,
                    dragAndDropAcrossControl: true,
                    cssClass: 'calcMemberTreeViewDragedNode',
                    nodeDropped: ej.proxy(function (args) {
                        if (args.target != null && args.target.attr("id") == "" + this._id + "_expressionFieldCM")
                            this.element.find("#" + this._id + "_expressionFieldCM").val(this.element.find("#" + this._id + "_expressionFieldCM").val() + $(args.droppedElement).attr("tag"));
                    }, this),
                    beforeExpand: ej.proxy(ej.Pivot._getMemberChildNodes, this),
                });
                this.element.find("#" + this._id + "_captionFieldCM").ejMaskEdit({
                    name: "inputbox",
                    inputMode: ej.InputMode.Text,
                    watermarkText: "",
                    maskFormat: "",
                    textAlign: this.model.enableRTL ? "right" : "left",
                    width: "100%"
                });
                this.element.find("#" + this._id + "_customFormatFieldCM").ejMaskEdit({
                    name: "inputbox",
                    inputMode: ej.InputMode.Text,
                    watermarkText: "",
                    maskFormat: "",
                    textAlign: this.model.enableRTL ? "right" : "left",
                    width: "100%",
                    cssClass: "calcMemberCustomFormat"
                });
                this.element.find(".calcMemberCustomFormat").css("visibility", "hidden");
                this.element.find("#" + this._id + "_memberTypeFieldCM").ejDropDownList({
                    dataSource: [{text: "Measure", value: "Measure"}, {text: "Dimension", value: "Dimension"}],
                    enableRTL: this.model.enableRTL,
                    width: "100%",
                    selectedIndex: 0,
                    change: ej.proxy(function (args) {
                        if (args.text == "Dimension")
                            this.element.find(".calcMemberDimensionField").css("visibility", "visible");
                        else
                            this.element.find(".calcMemberDimensionField").css("visibility", "hidden");
                    }, this)
                });
                var dimensions = ej.DataManager(calcMemberTreeData).executeLocal(ej.Query().where("spriteCssClass", "contains", "dimensionCDB"));
                var dimensionNames = [];
                for (var i = 0; i < dimensions.length; i++) {
                    dimensionNames.push({text: dimensions[i].name, value: dimensions[i].name})
                }
                this.element.find("#" + this._id + "_dimensionFieldCM").ejDropDownList({
                    dataSource: dimensionNames, selectedIndex: 0,
                    width: "100%", enableRTL: this.model.enableRTL, cssClass: "calcMemberDimensionField"
                });
                this.element.find(".calcMemberDimensionField").css("visibility", "hidden");
                this.element.find("#" + this._id + "_formatFieldCM").ejDropDownList({
                    dataSource: [{text: "Standard", value: "Standard"}, {
                        text: "Currency",
                        value: "Currency"
                    }, {text: "Percent", value: "Percent"}, {text: "Custom", value: "Custom"}],
                    enableRTL: this.model.enableRTL, selectedIndex: 0,
                    width: "100%", enableRTL: this.model.enableRTL, change: ej.proxy(function (args) {
                        if (args.text == "Custom")
                            this.element.find(".calcMemberCustomFormat").css("visibility", "visible");
                        else
                            this.element.find(".calcMemberCustomFormat").css("visibility", "hidden");
                    }, this)
                });
                var treeViewElements = this.element.find(".cubeTreeViewCalcMember").find("li");
                for (var i = 0; i < treeViewElements.length; i++) {
                    if (!ej.isNullOrUndefined($(treeViewElements[i]).attr("id")))
                        $(treeViewElements[i]).attr("tag", ej.DataManager(calcMemberTreeData).executeLocal(ej.Query().where("id", "equal", $(treeViewElements[i]).attr("id")))[0].tag);
                }
                var folders = this.element.find(".cubeTreeViewCalcMember .folderCDB");
                for (var i = 0; i < folders.length; i++) {
                    $(folders[i].parentElement).removeClass("e-draggable");
                }
                if (this.element.find(".cubeTreeViewCalcMember .calcMemberGroupCDB").length > 0)
                    this.element.find(".cubeTreeViewCalcMember .calcMemberGroupCDB").parent().removeClass("e-draggable");
                this._calcMemberTreeObj = this.element.find('.cubeTreeViewCalcMember').data("ejTreeView");
                if (!ej.isNullOrUndefined(this._selectedCalcMember)) {
                    var calcMember = ej.DataManager(this._calcMembers).executeLocal(ej.Query().where("name", "equal", this._selectedCalcMember));
                    if (calcMember.length > 0) {
                        this.element.find("#" + this._id + "_captionFieldCM").val(calcMember[0].name);
                        this.element.find("#" + this._id + "_expressionFieldCM").val(calcMember[0].expression);
                        this.element.find("#" + this._id + "_memberTypeFieldCM").data("ejDropDownList").selectItemsByIndices(calcMember[0].nodeType);
                        if (calcMember[0].nodeType == 1) {
                            var dimensionName = calcMember[0].tag.split(".")[0].replace(/\[/g, "").replace(/\]/g, "");
                            var dimensionFieldLen = this.element.find("#" + this._id + "_dimensionFieldCM").data("ejDropDownList").model.dataSource;
                            for (var i = 0; i < dimensionFieldLen.length; i++) {
                                if (dimensionFieldLen[i].value == dimensionName)
                                    this.element.find("#" + this._id + "_dimensionFieldCM").data("ejDropDownList").selectItemsByIndices(i);
                            }
                        }
                        if (!ej.isNullOrUndefined(calcMember[0].formatString)) {
                            if (calcMember[0].formatString == "Currency")
                                this.element.find("#" + this._id + "_formatFieldCM").data("ejDropDownList").selectItemsByIndices(1);
                            else if (calcMember[0].formatString == "Percent")
                                this.element.find("#" + this._id + "_formatFieldCM").data("ejDropDownList").selectItemsByIndices(2);
                            else {
                                this.element.find("#" + this._id + "_formatFieldCM").data("ejDropDownList").selectItemsByIndices(2);
                                this.element.find("#" + this._id + "_customFormatFieldCM").val(calcMember[0].formatString);
                            }
                        }
                    }
                }
                //$(".cubeBrowserHierarchy").ejScroller({ height: "300px", width: "300px" });
                //$("#calcMemberDialog").addClass("e-scheduledialog").find(".e-titlebar").addClass("e-dialogheader");
                this._waitingPopup.hide();
            },
            _getMemberChildNodes: function (args) {
                if ($(args.currentElement).find("a > span")[0].className.indexOf("level") > -1 || $(args.currentElement).find("a > span")[0].className.indexOf("member") > -1) {
                    var blankNode = ej.DataManager(this._calcMemberTreeObj.dataSource()).executeLocal(ej.Query().where("pid", "equal", $(args.currentElement).attr("id")).where("name", "equal", "(Blank)"));
                    if (!ej.isNullOrUndefined(blankNode) && blankNode.length > 0) {
                        this._calcMemberTreeObj.hideNode(blankNode[0].id);
                        this.pNode = args.currentElement;
                        this._waitingPopup.show();
                        var nodeType = $(args.currentElement).find("a > span")[0].className.indexOf("level") > -1 ? "level" : "member";
                        if (this.model.beforeServiceInvoke != null)
                            this._trigger("beforeServiceInvoke", {
                                action: "fetchMemberChildNodes",
                                element: this.element,
                                customObject: this.model.customObject
                            });
                        var serializedCustomObject = JSON.stringify(this.model.customObject);
                        this.doAjaxPost("POST", this.model.url + "/" + this.model.serviceMethodSettings.fetchMemberTreeNodes, JSON.stringify({
                            "action": "fetchMemberChildNodes",
                            "dimensionName": $(args.currentElement).attr("tag") + ":" + nodeType + ":" + $(args.currentElement).attr("id"),
                            "olapReport": this.currentReport,
                            "customObject": serializedCustomObject
                        }), ej.proxy(ej.Pivot._fetchMemberSuccess, this));
                    }
                }
            },
            _fetchMemberSuccess: function (data) {
                var childNodes = [];
                if (data.length > 1 && data[0] != undefined)
                    childNodes = JSON.parse(data[0].Value);
                else if (data.d != undefined)
                    childNodes = JSON.parse(data.d[0].Value);
                else
                    childNodes = JSON.parse(data.MemberChildNodes);
                if (this.model.afterServiceInvoke != null)
                    this._trigger("afterServiceInvoke", {
                        action: "fetchMemberChildNodes",
                        element: this.element,
                        customObject: this.model.customObject
                    });
                this._calcMemberTreeObj.model.beforeExpand = null;
                this._calcMemberTreeObj.addNode(childNodes, $(this.pNode));
                // this._calcMemberTreeObj.addNode()
                var blankNode = ej.DataManager(this._calcMemberTreeObj.dataSource()).executeLocal(ej.Query().where("pid", "equal", $(this.pNode).attr("id")).where("name", "equal", "(Blank)"));
                if (!ej.isNullOrUndefined(blankNode) && blankNode.length > 0) {
                    this._calcMemberTreeObj.removeNode(blankNode[0].id);
                }
                $.each($(this.pNode).children().find("li"), function (index, value) {
                    value.setAttribute("tag", childNodes[index].tag);
                });
                var elements = $(this.pNode).children().find("li");
                for (i = 0; i < elements.length; i++) {
                    if (childNodes[i].hasChildren == true) {
                        this._calcMemberTreeObj.addNode({
                            id: childNodes[i].id + "_Blank_" + i,
                            name: "(Blank)",
                            parentId: childNodes[i].id
                        }, elements[i]);
                        this.element.find("#" + childNodes[i].id).find('> div > div:first').removeClass("e-process");
                        this._calcMemberTreeObj.collapseNode(this.element.find("#" + childNodes[i].id));
                    }
                }
                this._calcMemberTreeObj.model.beforeExpand = ej.proxy(ej.Pivot._getMemberChildNodes, this);
                this._waitingPopup.hide();
            },
            _drillThroughCellClick: function (args, gridObj) {
                gridObj._waitingPopup.show();
                var measures, measureGrp;
                var cellPos = $(args.currentTarget.parentElement).attr('p');
                if (gridObj.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode) {
                    gridObj.doAjaxPost("POST", gridObj.model.url + "/" + gridObj.model.serviceMethodSettings.drillThroughDataTable, JSON.stringify({
                        "currentReport": JSON.parse(gridObj.getOlapReport()).Report,
                        "layout": gridObj.model.layout,
                        "cellPos": cellPos,
                        "customObject": JSON.stringify(gridObj.model.customObject)
                    }), function (args) {
                        if ($(gridObj.element).parents(".e-pivotclient").length > 0) {
                            $(gridObj.element).parents(".e-pivotclient").data("ejPivotClient")._trigger("drillThrough", {
                                element: gridObj.element,
                                data: args
                            });
                        }
                        else
                            gridObj._trigger("drillThrough", {element: gridObj.element, data: args});
                    });
                }
                else {
                    var rowSpan = $("#" + gridObj._id).find("tbody").find('tr:first').find('th').length;
                    for (i = 0; i < rowSpan; i++) {
                        var rowInfo = (gridObj.getJSONRecords()[parseInt((i * gridObj._rowCount) + parseInt(cellPos.split(",")[1]))].Info.indexOf("Measures") != -1 || gridObj.getJSONRecords()[parseInt((i * gridObj._rowCount) + parseInt(cellPos.split(",")[1]))].RowSpan <= 1) ? gridObj.getJSONRecords()[parseInt((i * gridObj._rowCount) + parseInt(cellPos.split(",")[1]))].Info.split("::")[0] : "";
                        if (rowInfo.indexOf("Measures") != -1)
                            measures = rowInfo;
                        if (rowInfo != "")
                            gridObj._rowHeader[i] = rowInfo;
                    }
                    var columnHeaderCount = $("#" + gridObj._id).find("tbody").find('[p="' + parseInt(cellPos.split(",")[0]) + "," + parseInt(cellPos.split(",")[1]) + '"]').closest('tbody').prev().children('tr').length;
                    for (i = 0; i < columnHeaderCount; i++) {
                        var colInfo = (gridObj.getJSONRecords()[parseInt((parseInt(cellPos.split(",")[0]) * gridObj._rowCount) + i)].Info.indexOf("Measures") != -1 || gridObj.getJSONRecords()[parseInt((parseInt(cellPos.split(",")[0]) * gridObj._rowCount) + i)].ColSpan <= 1) ? gridObj.getJSONRecords()[parseInt((parseInt(cellPos.split(",")[0]) * gridObj._rowCount) + i)].Info.split("::")[0] : "";
                        if (colInfo.indexOf("Measures") != -1)
                            measures = colInfo;
                        if (colInfo != "")
                            gridObj._colHeader[i] = colInfo;
                    }
                    if (ej.isNullOrUndefined(gridObj._fieldData) || (!ej.isNullOrUndefined(gridObj._fieldData) && ej.isNullOrUndefined(gridObj._fieldData.hierarchy)))
                        gridObj._getFieldItemsInfo(gridObj);
                    for (j = 0; j < gridObj._fieldData.measures.length; j++) {
                        if (measures == gridObj._fieldData.measures[j].id)
                            gridObj.measureGrp = gridObj._fieldData.measures[j].pid
                    }
                    gridObj._rowHeader = $.grep(gridObj._rowHeader, function (n) {
                        return n == 0 || n
                    });
                    gridObj._colHeader = $.grep(gridObj._colHeader, function (n) {
                        return n == 0 || n
                    });
                    gridObj._createDrillThroughQuery("", gridObj);
                }
            },
            openHierarchySelector: function (e, data) {
                if (e.model.operationalMode == ej.Pivot.OperationalMode.ServerMode)
                    this._createDrillThroughDialog(e, data);
                else {
                    var controlObj;
                    e._waitingPopup.show();
                    if (e.target.className.indexOf("e-pivotclient") >= 0)
                        controlObj = e._pivotGrid;
                    else controlObj = e;
                    var conStr = controlObj._getConnectionInfo(e.model.dataSource.data);
                    var pData = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Header/><Body><Discover xmlns=\"urn:schemas-microsoft-com:xml-analysis\"><RequestType>MDSCHEMA_MEASUREGROUP_DIMENSIONS</RequestType><Restrictions><RestrictionList><CATALOG_NAME>" + e.model.dataSource.catalog + "</CATALOG_NAME><CUBE_NAME>" + e.model.dataSource.cube + "</CUBE_NAME><MEASUREGROUP_NAME>" + controlObj.measureGrp + "</MEASUREGROUP_NAME></RestrictionList></Restrictions><Properties><PropertyList><Catalog>" + e.model.dataSource.catalog + "</Catalog> <LocaleIdentifier>" + conStr.LCID + "</LocaleIdentifier></PropertyList></Properties></Discover></Body></Envelope>";
                    this.doAjaxPost("POST", conStr.url, {XMLA: pData}, controlObj._loadDimensionElements, null, {
                        pvtGridObj: controlObj,
                        action: "loadMeasureElements"
                    });
                }
            },

            _createDrillThroughDialog: function (args, dataSourceInfo) {
                if (args.model.operationalMode != ej.PivotGrid.OperationalMode.ServerMode)
                    dataSourceInfo.shift();
                args.element.find(".e-dialog:not(.calcMemberDialog, .calcMemberDialog .e-dialog), .clientDialog").remove();
                var textTitle = ej.buildTag("label#", args._getLocalizedLabels("SelectHierarchy"))[0].outerHTML;
                var textArea = "<br><textarea id='hrSel' style='width:270px; height:300px; resize:none; margin:0px 5px 0 5px'></textarea></br><br>",
                    browserPanel = "<div class=cubeTable style='width:200px; overflow:auto'><div valign=\"bottom\">" + this._createHierarchyBrowser() + "</div></div>";
                var dialogContent = ej.buildTag("div#dropDlg.dropDlg", "<table class=\"outerTable\"><tr><td>" + browserPanel + "</td><td>" + textTitle + textArea + "</td></tr></table>")[0].outerHTML + "</br>",
                    dialogFooter = ej.buildTag("div", ej.buildTag("button#btnOK.dialogBtnOK", args._getLocalizedLabels("OK"))[0].outerHTML + ej.buildTag("button#btnCancel.dialogBtnCancel", args._getLocalizedLabels("Cancel"))[0].outerHTML, {
                        "float": "right",
                        "margin": "-5px 0 6px"
                    })[0].outerHTML,
                    ejDialog = ej.buildTag("div#clientDialog.clientDialog", dialogContent + dialogFooter, {"opacity": "1"}).attr("title", "Hierarchy Selector")[0].outerHTML;
                $(ejDialog).appendTo("#" + args._id);
                $("#btnOK, #btnCancel").ejButton();
                $("#btnOK, #btnCancel").css({margin: "0 20px 20px 0", width: "50px"});
                args.element.find(".clientDialog").ejDialog({
                    width: 550,
                    target: "#" + args._id,
                    enableResize: false,
                    enableRTL: args.model.enableRTL,
                    close: ej.proxy(ej.Pivot.closePreventPanel, args)
                });
                args.element.find(".cubeTreeViewHierarchy").ejTreeView({
                    showCheckbox: true,
                    fields: {
                        id: "id",
                        parentId: "pid",
                        text: "name",
                        isChecked: "isSelected",
                        spriteCssClass: "spriteCssClass",
                        dataSource: args.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode ? $.parseJSON(dataSourceInfo.d) : dataSourceInfo
                    },
                    allowDragAndDrop: true,
                    allowDropChild: false,
                    allowDropSibling: false,
                    enableRTL: args.model.enableRTL ? true : false,
                    beforeDelete: function () {
                        return false;
                    },
                    dragAndDropAcrossControl: true,
                    nodeDropped: ej.proxy(this._hierarchyNodeDropped, args),
                });
                args._tableTreeObj = args.element.find(".cubeTreeViewHierarchy").data("ejTreeView");
                args._tableTreeObj.element.find(".e-ul").css({"width": "100%", "height": "100%"});
                args._tableTreeObj.element.find(".e-chkbox-wrap").remove();
                var treeViewElements = args._tableTreeObj.element.find("li");
                for (var i = 0; i < treeViewElements.length; i++) {
                    var tagValue = args.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode ? $.parseJSON(dataSourceInfo.d)[i].tag : dataSourceInfo[i].tag
                    treeViewElements[i].setAttribute("tag", tagValue);
                }
                if (args._tableTreeObj) {
                    args._tableTreeObj.element.find("li").mouseover(ej.proxy(function (evt) {
                        if ($(evt.target).parent().find(".measureGroupCDB, .dimensionCDB, .folderCDB").length > 0)
                            $(evt.target).css("cursor", "default");
                    }, args));
                }
                var grid = args;
                $("#btnOK").click(function () {
                    var text = $("#hrSel").val();
                    $(".e-dialog:not(.calcMemberDialog, .calcMemberDialog .e-dialog), .clientDialog, .drilltableDialog").remove();
                    grid._waitingPopup.show();
                    ej.olap._mdxParser._createDrillThroughQuery(text, grid);
                    grid._waitingPopup.hide();
                });
                $("#btnCancel").click(function () {
                    $(".e-dialog:not(.calcMemberDialog, .calcMemberDialog .e-dialog), .clientDialog").remove();
                    grid._waitingPopup.hide()
                });
                if (args.model.enableRTL) {
                    $('.e-dialog').addClass("e-rtl");
                    $('.dialogBtnCancel').css("margin", "0 -70px 0 0");
                }
            },

            _createHierarchyBrowser: function (cubeTreeInfo) {
                return ej.buildTag("div.cubeBrowserHierarchy", ej.buildTag("div.cubeTreeViewHierarchy")[0].outerHTML, {
                    width: "200px",
                    height: "300px",
                    overflow: "auto"
                })[0].outerHTML;
            },

            _hierarchyNodeDropped: function (sender) {
                if (sender.dropTarget[0].id == "hrSel") {
                    var target;
                    if ($($(sender.droppedElement).children()[0]).find(".dimensionCDB").length > 0)
                        target = this.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode ? $(sender.droppedElement).find("li:first").attr("tag") : $(sender.droppedElement).find("li:first")[0].id;
                    else if ($(sender.droppedElement).find("li:first").length == 0)
                        target = this.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode ? $(sender.droppedElement.parent().parent()).attr("tag") : $(sender.droppedElement.parent().parent())[0].id;
                    else
                        target = this.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode ? $(sender.droppedElement).attr("tag") : sender.droppedElementData.id;
                    target = target.replace("[", "[$");
                    for (var i = 0; i < $("#hrSel").val().split(",").length; i++) {
                        if (target == $("#hrSel").val().split(",")[i])
                            return false;
                    }
                    var tex = this.element.find('#hrSel').val();
                    if (tex.length != 0) {
                        tex = tex + ',' + target;
                        this.element.find('#hrSel').val(tex);
                    }
                    else
                        this.element.find('#hrSel').val(target);
                }
            },

            _generateDrillData: function (customArgs, args) {
                var tag = $(args).find("row").children();
                var json = $.map(tag, function (a) {
                    var num = parseFloat(a.textContent);
                    var text = a.tagName.replace(/_x005B_/g, "[").replace(/_x0020_/g, " ").replace(/_x005D_/g, "]").replace(/_x0024_/g, "$").replace("].[", "]-[");
                    return '"' + text + '"' + ":" + num;
                })
                var value = json[0], gridJSON = "";
                for (var i = 0; i < json.length; i++) {
                    if (json[i] == value) {
                        gridJSON += gridJSON == "" ? "[{" + json[i] : "}, {" + json[i];
                        continue;
                    }
                    gridJSON += "," + json[i];
                }
                gridJSON += "}]";
                if ($(customArgs.pvtGridObj.element).parents(".e-pivotclient").length > 0) {
                    $(customArgs.pvtGridObj.element).parents(".e-pivotclient").data("ejPivotClient")._trigger("drillThrough", {
                        element: customArgs.pvtGridObj.element,
                        data: gridJSON
                    });
                }
                else
                    customArgs.pvtGridObj._trigger("drillThrough", {
                        element: customArgs.pvtGridObj.element,
                        data: gridJSON
                    });
            },

            _getFilterState: function (olapClientMode, members, item, controlObj) {
                var filterState = "";
                if (controlObj.model.operationalMode == ej.Pivot.OperationalMode.ClientMode) {
                    if (olapClientMode) {
                        if (controlObj._fieldSelectedMembers[item.fieldName.toLowerCase()] == "All" || ej.isNullOrUndefined(controlObj._fieldSelectedMembers[item.fieldName.toLowerCase()]))
                            ej.olap._mdxParser.getAllMember(controlObj.model.dataSource, item.fieldName, controlObj);
                        filterState = (controlObj._fieldSelectedMembers[item.fieldName.toLowerCase()] == "All" || ej.isNullOrUndefined(controlObj._fieldSelectedMembers[item.fieldName.toLowerCase()]) ? controlObj._allMember : controlObj._fieldSelectedMembers[item.fieldName.toLowerCase()]);
                    }
                    else {
                        if (item.filterItems.filterType == "include") {
                            if (item.filterItems.values.length == 1)
                                filterState = item.filterItems.values[0];
                            else
                                filterState = controlObj._getLocalizedLabels("MultipleItems");
                        }
                        else {
                            if (members.length - (item.filterItems.values.indexOf("All") == -1 ? item.filterItems.values.length : item.filterItems.values.length - 1) == 1)
                                filterState = members.filter(function (itm) {
                                    if (item.filterItems.values.indexOf(itm.toString()) == -1) return itm
                                });
                            else
                                filterState = controlObj._getLocalizedLabels("MultipleItems");
                        }
                    }
                }
                else {
                    if (controlObj.model.analysisMode == ej.Pivot.AnalysisMode.Pivot) {
                        var excludeMem = !ej.isNullOrUndefined(controlObj._tempFilterData) ? $.map(controlObj._tempFilterData, function (itm) {
                            return itm[item.DimensionHeader]
                        }) : [];
                        if (excludeMem.length > 0 && controlObj._fieldMembers[item.DimensionHeader])
                            filterState = controlObj._fieldMembers[item.DimensionHeader].length - excludeMem.length == 1 ? (controlObj._fieldMembers[item.DimensionHeader]).filter(function (itm) {
                                if (excludeMem.indexOf(itm) == -1) return itm
                            }) : controlObj._getLocalizedLabels("MultipleItems");
                        else
                            filterState = controlObj._getLocalizedLabels("All");
                    }
                    else {
                        filterState = (controlObj._fieldSelectedMembers[item.Tag] == "All" ? item.AllMember : controlObj._fieldSelectedMembers[item.Tag]) || item.AllMember;
                    }
                }
                return filterState;
            },

            _getTreeViewItems: function (controlObj) {
                var treeElement = controlObj.element.find(".editorTreeView");
                var treeItems = [];
                var data = $(treeElement).find(':input.nodecheckbox');
                for (var i = 0; i < data.length; i++) {
                    var parentNode = $(data[i]).parents('li:eq(0)');
                    treeItems.push({Id: parentNode[0].id, name: $(parentNode[0]).find('a:eq(0)').text()});
                }
                return treeItems;
            },

            _getEditorMember: function (data, controlObj, isSchema) {
                if (controlObj.model.operationalMode == ej.PivotGrid.OperationalMode.ClientMode) {
                    var tmpItems = this._getTreeViewItems(isSchema ? controlObj._schemaData : controlObj);
                    var ds = $.extend(true, [], isSchema ? controlObj._schemaData._memberTreeObj.dataSource() : controlObj._memberTreeObj.dataSource());
                    var treeItems = $.map(tmpItems, function (item1) {
                        if (item1.Id != "All") {
                            $.map(ds, function (item2) {
                                if (item1.Id == item2.id) {
                                    item1 = item2;
                                    item1.name = ej.isNullOrUndefined(item1.parentId) ? item1.name + "_" + 1 : item1.name;
                                }
                            });
                            return item1;
                        }
                    });
                    var nodes = [];
                    var items = $.map(treeItems, function (item1) {
                        $.map(treeItems, function (item2) {
                            if (item1.parentId == item2.id) {
                                item1.name = item1.name + "_" + (Number(item2.name.split('_')[item2.name.split('_').length - 1]) + 1);
                            }
                        });
                        return item1;
                    });
                    $.map(items, function (item) {
                        var val = item.name.split('_')[item.name.split('_').length - 2];
                        var lvl = Number(item.name.split('_')[item.name.split('_').length - 1]);
                        var chkState = item.checkedStatus;
                        nodes.push({name: val, checked: chkState, level: Number(lvl)});
                    });

                    return this._updateEditorMembers(data, nodes, controlObj);
                }
                else {
                    if (controlObj.model.analysisMode == ej.Pivot.AnalysisMode.Olap) {
                        var nodes = [];
                        if (controlObj.model.operationalMode == ej.PivotGrid.OperationalMode.ServerMode && controlObj.model.enableMemberEditorPaging) {
                            var items = controlObj._editorTreeData;
                            $.map(items, function (item) {
                                var val = item.name;
                                var lvl = item.id.split('_')[item.id.split('_').length - 1];
                                var chkState = item.checkedStatus;
                                nodes.push({name: val, checked: chkState, level: Number(lvl)});
                            });
                        }
                        else {
                            var treeElement = isSchema ? controlObj._schemaData.element.find('.editorTreeView') : controlObj.element.find(".editorTreeView");
                            var items = $(treeElement).find(':input.nodecheckbox');
                            $.map(items, function (item) {
                                if ($(item).parents('li:eq(0)').attr("id") != "All") {
                                    var val = $(item).parent().siblings('a').text();
                                    var lvl = item.value.split('_')[item.value.split('_').length - 1];
                                    var chkState = item.checked || $(item.parentElement).attr('aria-checked') == 'mixed' ? true : false;
                                    nodes.push({name: val, checked: chkState, level: Number(lvl)});
                                }
                            });
                        }
                        return this._updateEditorMembers(data, nodes, controlObj);
                    }
                    else {
                        textArr = [];
                        for (var i = 1; i < data.length; i++)
                            textArr.push($(data[i].parentElement).siblings("a").text());
                        return textArr;
                    }
                }
            },

            _updateEditorMembers: function (data, nodes, controlObj) {
                if (!ej.isNullOrUndefined(controlObj._fieldMembers[data])) {
                    var tmpArray = [], buffer = 0, member = "";
                    var savedFields = controlObj._fieldMembers[data];
                    for (var i = 0; i < nodes.length; i++) {
                        if (ej.isNullOrUndefined(savedFields[i + buffer]) || nodes[i].level == savedFields[i + buffer].level) {
                            tmpArray.push(nodes[i]);
                        }
                        else if (ej.isNullOrUndefined(savedFields[i + buffer]) || nodes[i].level < savedFields[i + buffer].level) {
                            var count = i;
                            do {
                                if (nodes[i - 1].checked)
                                    tmpArray.push(savedFields[count]);
                                buffer++;
                                count++;
                            } while (nodes[i].level < savedFields[count].level);
                            i--;
                        }
                        else if (ej.isNullOrUndefined(savedFields[i + buffer]) || nodes[i].level > savedFields[i + buffer].level) {
                            var svdlvl = savedFields[i + buffer].level;
                            var count = i;
                            do {
                                tmpArray.push(nodes[count]);
                                buffer--;
                                count++;
                                i = count - 1;
                            } while (nodes[count].level > svdlvl);
                        }
                    }
                }
                controlObj._fieldMembers[data] = ej.isNullOrUndefined(controlObj._fieldMembers[data]) ? nodes : tmpArray;


                var lvl = 1, parent = "", state = "", checkedMembers = [];
                do {
                    var lvlMembers = $.map(controlObj._fieldMembers[data], function (item) {
                        if (item.level == lvl)
                            return item;
                    });
                    checkedMembers = $.map(lvlMembers, function (item) {
                        if (item.checked)
                            return item;
                    });
                    if (lvlMembers.length == checkedMembers.length) {
                        member = lvl == 1 ? "All" : parent;
                        if (lvlMembers.length > 1)
                            state = "All";
                        lvl++;
                    }
                    else if (checkedMembers.length == 1) {
                        parent = member = state == "All" ? "multiple" : checkedMembers[0].name;
                        lvl++;
                    }
                    else if (checkedMembers.length > 1 && lvlMembers.length > checkedMembers.length) {
                        member = "multiple";
                        break;
                    }
                } while (checkedMembers.length > 0 && member != "All" && member != "multiple" && $.map(controlObj._fieldMembers[data], function (item) {
                    if (item.level == lvl) return item;
                }).length > 0);

                return member;
            },

            _getTreeData: function (args, successMethod, customArgs) {
                var conStr = ej.olap.base._getConnectionInfo(args.url);
                var xmlMsg = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Header/><Body><Discover xmlns=\"urn:schemas-microsoft-com:xml-analysis\"><RequestType>" + args.request + "</RequestType><Restrictions><RestrictionList><CATALOG_NAME>" + args.catalog + "</CATALOG_NAME>" +
                    (customArgs.action == "loadcubelist" ? "" : "<CUBE_NAME>" + args.cube + "</CUBE_NAME>") + "</RestrictionList></Restrictions><Properties><PropertyList><Catalog>" + args.catalog + "</Catalog><LocaleIdentifier>" + conStr.LCID + "</LocaleIdentifier> </PropertyList></Properties></Discover></Body></Envelope>";
                customArgs.action = "loadFieldElements";
                this.doAjaxPost("POST", conStr.url, {XMLA: xmlMsg}, successMethod, null, customArgs);
            },

            updateTreeView: function (controlObj) {
                var treeViewElements = controlObj.element.find(".editorTreeView").find("li"),
                    treeViewLength = treeViewElements.length, dataSource = controlObj._memberTreeObj.dataSource(),
                    dSourceLen = dataSource.length;

                for (var i = 0; i < treeViewLength; i++) {
                    var isAreaChecked = $(treeViewElements[i]).find("span:first").attr('aria-checked');
                    for (var j = 0; j < dSourceLen; j++) {
                        if (treeViewElements[i]["id"] == dataSource[j]["id"] && (isAreaChecked == "mixed" || isAreaChecked == "true")) {
                            dataSource[j]["checkedStatus"] = true;
                            break;
                        }
                        else if (treeViewElements[i]["id"] == dataSource[j]["id"] && isAreaChecked == "false") {
                            dataSource[j]["checkedStatus"] = false;
                            break;
                        }
                    }
                }
                for (var i = 0; i < dataSource.length; i++) {
                    var memberStatus = false;
                    if (dataSource[i]["checkedStatus"] == true) {
                        for (var j = 0; j < dataSource.length; j++) {
                            if (dataSource[j].hasOwnProperty("parentId") && dataSource[j]["parentId"] == dataSource[i]["id"] && dataSource[j]["checkedStatus"] == true) {
                                memberStatus = true;
                                break;
                            }
                        }
                        if (!memberStatus) {
                            for (var m = 0; m < dataSource.length; m++) {
                                if (dataSource[m].hasOwnProperty("parentId") && dataSource[m]["parentId"] == dataSource[i]["id"])
                                    dataSource[m]["checkedStatus"] = true;
                            }
                        }
                    }
                    else if (dataSource[i]["checkedStatus"] == false) {
                        for (var k = 0; k < dataSource.length; k++) {
                            if (dataSource[k].hasOwnProperty("parentId") && dataSource[k]["parentId"] == dataSource[i]["id"])
                                dataSource[k]["checkedStatus"] = false;
                        }
                    }
                }
                for (var i = 0; i < treeViewLength; i++) {
                    if ($(treeViewElements[i]).attr("tag") == null || undefined) {
                        for (var j = 0; j < dSourceLen; j++) {
                            if ($(treeViewElements[i]).attr("id") == dataSource[j]["id"]) {
                                $(treeViewElements[i]).attr("tag", dataSource[j]["tag"]);
                                break;
                            }
                        }
                    }
                }
                return controlObj._memberTreeObj;
            },

            getNodesState: function (treeViewObj) {
                var selectedNodes = "", unSelectedNodes = "", dataSource = [];
                ;
                if (treeViewObj.pluginName == "ejTreeView")
                    dataSource = treeViewObj.dataSource();
                else
                    dataSource = treeViewObj
                for (var i = 0; i < dataSource.length; i++) {
                    if (dataSource[i].checkedStatus == true)
                        selectedNodes += "::" + dataSource[i].id + "||" + dataSource[i].tag + "||" + dataSource[i].parentId + "||" + dataSource[i].name;
                    else
                        unSelectedNodes += "::" + dataSource[i].parentId + "||" + dataSource[i].tag + "||" + dataSource[i].name;
                }
                return {selectedNodes: selectedNodes, unSelectedNodes: unSelectedNodes};
            },

            removeParentSelectedNodes: function (selectedNodes) {
                var selectedElements = $.extend([], selectedNodes);
                for (var i = 0; i < selectedNodes.length; i++) {
                    for (var j = 0; j < selectedElements.length; j++) {
                        if (selectedElements[j].Id == selectedNodes[i].parentId)
                            selectedElements.splice(j, 1);
                    }
                }
                return $.map(selectedElements, function (element, index) {
                    if (element.tag != "" && element.tag != undefined) return element.tag.replace(/\&/g, "&amp;")
                });
            },

            getChildNodes: function (args, currentHierarchy, treeViewCollection, dataSource, ctrlObj) {
                var selectedItem = args.targetElement, tagInfo, cubeName = dataSource.cube,
                    catloagName = dataSource.catalog, url = dataSource.data,
                    successMethod = ctrlObj._generateChildMembers,
                    childCount = $(args.currentElement).find("li").length, isLoadOnDemand = false;
                if (childCount == 0) {
                    var onLoad = ej.buildTag("span.nodeExpand e-load e-icon")[0].outerHTML;
                    var currMember = $(selectedItem).parents("li:eq(0)").attr("id");
                    var reportItem = $.map(treeViewCollection, function (obj, index) {
                        if (obj["fieldName"] == currentHierarchy && !ej.isNullOrUndefined(obj["filterItems"])) {
                            var filterItems = obj["filterItems"];
                            if (ej.isNullOrUndefined(ctrlObj.model.pivotControl) ? ctrlObj.model.enableMemberEditorPaging : ctrlObj.model.pivotControl.model.enableMemberEditorPaging) {
                                filterItems = $.map(filterItems, function (obj, index) {
                                    if (obj["pid"] != undefined && obj["pid"] == currMember.replace(/\]*\]/g, '-').replace(/\[*\[/g, '-')) {
                                        isLoadOnDemand = true;
                                        return obj;
                                    }
                                });
                                if (filterItems.length > 0 && isLoadOnDemand == true) {
                                    $(selectedItem).parents("li:eq(0)").find(".nodeExpand").remove();
                                    $(selectedItem).parents("li:eq(0)").find(".e-load").removeClass("e-load");
                                    $.each(filterItems, function (index, value) {
                                        delete value.parentId
                                    });
                                    ctrlObj._memberTreeObj.addNode(filterItems, $(selectedItem).parents("li:eq(0)"));
                                    $.each($(selectedItem).parents("li:eq(0)").find("li"), function (index, value) {
                                        value.setAttribute("tag", filterItems[index].tag);
                                    });
                                }
                            }
                            else {
                                $.map(filterItems, function (obj, index) {
                                    if (obj["parentId"] != undefined && obj["parentId"] == currMember.replace(/\]*\]/g, '-').replace(/\[*\[/g, '-'))
                                        isLoadOnDemand = true;
                                });
                            }
                        }
                    });
                    isLoadOnDemand ? args.isChildLoaded = true : args.isChildLoaded = false
                    if (!isLoadOnDemand) {
                        $(selectedItem).parents("li:eq(0)").prepend(onLoad);
                        if ($(selectedItem).parents("li:eq(0)").attr("tag") == undefined) {
                            var filterItem = $.map(treeViewCollection, function (obj, index) {
                                if (obj["fieldName"] == currentHierarchy) return obj;
                            })[0]
                            if (filterItem)
                                $.map(filterItem["filterItems"], function (obj, index) {
                                    if (obj["id"] == $(selectedItem).parents("li:eq(0)").attr("id")) $(selectedItem).parents("li:eq(0)").attr("tag", obj["tag"]);
                                });
                        }
                        var uniqueName = $(selectedItem).parents("li:eq(0)").attr("tag").replace(/\&/g, "&amp;");
                        ej.olap._mdxParser.getChildren(dataSource, uniqueName, ctrlObj);
                    }
                }
            },
            _getFilterParams: function (droppedClass, tempFilterData, headerText) {
                var filterParams = "";
                if (droppedClass != "schemaValue") {
                    var filterData = "";
                    if (!ej.isNullOrUndefined(tempFilterData)) {
                        for (var i = 0; i < tempFilterData.length; i++) {
                            if (!ej.isNullOrUndefined(tempFilterData[i][headerText])) {
                                for (var j = 0; j < tempFilterData[i][headerText].length; j++) {
                                    filterData += "##" + tempFilterData[i][headerText][j];
                                }
                            }
                        }
                    }
                    if (filterData != "")
                        filterParams = droppedClass + "::" + headerText + "::FILTERED" + filterData;
                }
                return filterParams;
            },
            generateChildMembers: function (customArgs, args) {
                var data = $(args).find("Axis:eq(0) Tuple"), treeViewData = [];
                var pNode = $("[tag='" + customArgs.currentNode.replace(/&amp;/g, "&") + "']");
                for (var i = 0; i < data.length; i++) {
                    var memberUqName = $($(args).find("Axis:eq(0) Tuple:eq(" + i + ")").children().children()[0]).text();
                    var memberName = $($(args).find("Axis:eq(0) Tuple:eq(" + i + ")").children()).find("Caption").text() == "" ? "(Blank)" : $($(args).find("Axis:eq(0) Tuple:eq(" + i + ")").children()).find("Caption").text();
                    var treeNodeInfo = {
                        hasChildren: $(data[i]).find("CHILDREN_CARDINALITY").text() != "0",
                        checkedStatus: false,
                        id: memberUqName.replace(/\]*\]/g, '-').replace(/\[*\[/g, '-'),
                        name: memberName,
                        tag: memberUqName
                    }
                    treeViewData.push(treeNodeInfo);
                }
                if ($(pNode).parents("li").length > 1)
                    parentNode = $(pNode).parents("li").first();
                else
                    parentNode = $(pNode).parents("li");
                $($(parentNode).find('input.nodecheckbox')[0]).ejCheckBox({checked: false})
                this._memberTreeObj = $(".editorTreeView").data("ejTreeView");

                if (treeViewData.length > 0 && !ej.isNullOrUndefined(this.model) && this.model.pivotControl.element.hasClass("e-pivotclient") && this.model.pivotControl.model.enableMemberEditorPaging) {
                    var hierarchyName = this._selectedFieldName;
                    var editorControl = this.model.pivotControl;
                    $.map(this.model.pivotControl._currentReportItems, function (obj, index) {
                        if (obj["fieldName"] == hierarchyName && !ej.isNullOrUndefined(obj["filterItems"])) {
                            $.each(treeViewData, function (index, value) {
                                value.pid = $(pNode).attr("id");
                            });
                            $.merge(obj["filterItems"], treeViewData);
                            editorControl._editorTreeData = obj["filterItems"];
                        }
                    });
                }
                pNode.find(".nodeExpand").remove();
                pNode.find(".e-load").removeClass("e-load");
                this._memberTreeObj.addNode(treeViewData, $(pNode));
                $.each(pNode.find("li"), function (index, value) {
                    value.setAttribute("tag", treeViewData[index].tag);
                });
            },

            createAdvanceFilterTag: function (args, ctrlObj) {
                var filterTag = "", seperator = ej.buildTag("li.e-separator").css("margin-left", "29px")[0].outerHTML,
                    opMode = ctrlObj.element.hasClass("e-pivotschemadesigner") ? ctrlObj.model.pivotControl.model.operationalMode : ctrlObj.model.operationalMode,
                    analysisMode = ctrlObj.element.hasClass("e-pivotschemadesigner") ? ctrlObj.model.pivotControl.model.analysisMode : ctrlObj.model.analysisMode;
                if (args.action == "filterTag") {
                    filterTag = [{
                        id: "ascOrder",
                        text: ctrlObj._getLocalizedLabels("SortAtoZ"),
                        parentId: null,
                        spriteCssClass: "ascImage e-icon"
                    },
                        {
                            id: "descOrder",
                            text: ctrlObj._getLocalizedLabels("SortZtoA"),
                            parentId: null,
                            spriteCssClass: "descImage e-icon"
                        },
                        {
                            id: "clearSorting",
                            text: ctrlObj._getLocalizedLabels("ClearSorting"),
                            parentId: null,
                            spriteCssClass: "e-clrSort e-icon"
                        },
                        {id: "sep", parentId: null, text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "clearAllFilters",
                            text: ctrlObj._getLocalizedLabels("ClearFilterFrom"),
                            parentId: null,
                            spriteCssClass: "e-clrFilter e-icon"
                        },
                        {id: "labelFilterBtn", text: ctrlObj._getLocalizedLabels("LabelFilters"), parentId: null},
                        {id: "valueFilterBtn", text: ctrlObj._getLocalizedLabels("ValueFilters"), parentId: null},
                        {
                            id: "labelClearFilter",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("ClearFilter"),
                            spriteCssClass: "e-clrFilter e-icon"
                        },
                        {id: "sep", parentId: "labelFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "equals",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("Equals"),
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "notequals",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("DoesNotEquals") + "...",
                            spriteCssClass: "sprite"
                        },
                        {id: "sep", parentId: "labelFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "beginswith",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("BeginsWith") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "notbeginswith",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("DoesNotBeginsWith") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "endswith",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("EndsWith") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "notendswith",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("DoesNotEndsWith") + "...",
                            spriteCssClass: "sprite"
                        },
                        {id: "sep", parentId: "labelFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "contains",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("Contains") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "notcontains",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("DoesNotContains") + "...",
                            spriteCssClass: "sprite"
                        },
                        {id: "sep", parentId: "labelFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "greaterthan",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("GreaterThan") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "greaterthanorequalto",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("GreaterThanOrEqualTo") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "lessthan",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("LessThan") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "lessthanorequalto",
                            parentId: "labelFilterBtn",
                            text: ctrlObj._getLocalizedLabels("LessThanOrEqualTo") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "valueClearFilter",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("ClearFilter"),
                            spriteCssClass: "e-clrFilter e-icon"
                        },
                        {id: "sep", parentId: "valueFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "equals",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("Equals"),
                            spriteCssClass: "equals"
                        },
                        {
                            id: "notequals",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("DoesNotEquals") + "...",
                            spriteCssClass: "sprite"
                        },
                        {id: "sep", parentId: "valueFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "greaterthan",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("GreaterThan") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "greaterthanorequalto",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("GreaterThanOrEqualTo") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "lessthan",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("LessThan") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "lessthanorequalto",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("LessThanOrEqualTo") + "...",
                            spriteCssClass: "sprite"
                        },
                        {id: "sep", parentId: "valueFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "between",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("Between") + "...",
                            spriteCssClass: "sprite"
                        },
                        {
                            id: "notbetween",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("NotBetween") + "...",
                            spriteCssClass: "sprite"
                        },
                        {id: "sep", parentId: "valueFilterBtn", text: "", spriteCssClass: "e-seperator"},
                        {
                            id: "topCount",
                            parentId: "valueFilterBtn",
                            text: ctrlObj._getLocalizedLabels("Top10") + "...",
                            spriteCssClass: "sprite"
                        }
                    ];

                    if (opMode == ej.Pivot.OperationalMode.ClientMode || (opMode == ej.Pivot.OperationalMode.ServerMode && analysisMode == ej.Pivot.AnalysisMode.Pivot))
                        filterTag.splice(filterTag.length - 1, 2);
                    else
                        filterTag.splice(0, 5);

                }
                else if (args.action == "clearFilter") {
                    filterTag = ej.buildTag("div.clearSorting", ej.buildTag("span.e-clrSort", "", {"padding": "0px 10px 0px 4px"}).addClass("e-icon").attr("aria-label", "clear sort")[0].outerHTML + ej.buildTag("span.clearSortText", "Clear Sorting", {"padding": "5px 0px"})[0].outerHTML)[0].outerHTML + ej.buildTag("div.separator", {"padding": "5px 0px"})[0].outerHTML +
                        ej.buildTag("div.clearAllFilters", ej.buildTag("span.e-clrFilter", "", {"padding": "0px 10px 0px 4px"}).addClass("e-icon").attr("aria-label", " clear filter")[0].outerHTML + ej.buildTag("span.clearFltrText", "Clear Filter From\"" + args.selectedLevel.text + "\"", {"padding": "5px 0px"})[0].outerHTML)[0].outerHTML;
                }
                else if (args.action == "sort") {
                    filterTag = ej.buildTag("div#sortDiv.sortDiv",
                        ej.buildTag("li#ascOrder.ascOrder", ej.buildTag("span.ascImage").addClass("e-icon").attr("aria-label", "ascending")[0].outerHTML + ctrlObj._getLocalizedLabels("Sort") + " A to Z")[0].outerHTML +
                        ej.buildTag("li#descOrder.descOrder", ej.buildTag("span.descImage").addClass("e-icon").attr("aria-label", "descending")[0].outerHTML + ctrlObj._getLocalizedLabels("Sort") + " Z to A")[0].outerHTML)[0].outerHTML;
                }
                else if (args.action == "labelFilterDlg" || args.action == "valueFilterDlg") {

                    var dialogContent = "", dropdownValues = [];
                    if (args.action == "labelFilterDlg") {
                        dialogContent = ej.buildTag("table.labelfilter",
                            ej.buildTag("tr", ej.buildTag("td", ctrlObj._getLocalizedLabels("LabelFilterLabel")).attr("colspan", "2")[0].outerHTML)[0].outerHTML +
                            ej.buildTag("tr", ej.buildTag("td", "<input type='text' id='filterOptions' class='filterOptions'  style='width:220px'/>")[0].outerHTML +
                                ej.buildTag("td.filterValuesTd", "<input type='text' id='filterValue1'  value='" + (args.filterInfo.length > 0 ? (opMode == ej.Pivot.OperationalMode.ClientMode ? args.filterInfo[0].values[0] : args.filterInfo[0].value1) : "") + "' style='display:inline; width:160px; height:19px; margin-left:7px;' class='filterValues'/></br>")[0].outerHTML)[0].outerHTML)[0].outerHTML;

                        dropdownValues = [{
                            value: "equals",
                            option: ctrlObj._getLocalizedLabels("Equals").toLowerCase()
                        },
                            {value: "not equals", option: ctrlObj._getLocalizedLabels("DoesNotEquals").toLowerCase()},
                            {value: "begins with", option: ctrlObj._getLocalizedLabels("BeginsWith").toLowerCase()},
                            {
                                value: "not begins with",
                                option: ctrlObj._getLocalizedLabels("DoesNotBeginsWith").toLowerCase()
                            },
                            {value: "ends with", option: ctrlObj._getLocalizedLabels("EndsWith").toLowerCase()},
                            {
                                value: "not ends with",
                                option: ctrlObj._getLocalizedLabels("DoesNotEndsWith").toLowerCase()
                            },
                            {value: "contains", option: ctrlObj._getLocalizedLabels("Contains").toLowerCase()},
                            {
                                value: "not contains",
                                option: ctrlObj._getLocalizedLabels("DoesNotContains").toLowerCase()
                            },
                            {value: "greater than", option: ctrlObj._getLocalizedLabels("IsGreaterThan").toLowerCase()},
                            {
                                value: "greater than or equal to",
                                option: ctrlObj._getLocalizedLabels("IsGreaterThanOrEqualTo").toLowerCase()
                            },
                            {value: "less than", option: ctrlObj._getLocalizedLabels("IsLessThan").toLowerCase()},
                            {
                                value: "less than or equal to",
                                option: ctrlObj._getLocalizedLabels("IsLessThanOrEqualTo").toLowerCase()
                            },
                        ];
                    }
                    else {
                        var measureNames = new Array(), innerContent,
                            colSpan = ($(args["selectedArgs"].element).attr("id") == ("between") || $(args["selectedArgs"].element).attr("id") == ("notbetween") || (args["selectedArgs"].value == "between" || args["selectedArgs"].value == "not between")) ? "4" : "3";
                        if (ctrlObj.element.find(".cubeTreeView ").length > 0) {
                            measureNames = $.map(ctrlObj.element.find(".cubeTreeView [tag*='[Measures]'] "), function (currentElement, index) {
                                return {option: $(currentElement).text(), value: $(currentElement).attr("tag")}
                            });
                        }
                        else {
                            var pvtBtns = ctrlObj.element.hasClass("e-pivotschemadesigner") ? ctrlObj.element.find(".schemaValue .pivotButton") : ctrlObj.element.find(".groupingBarPivot .values .pivotButton");
                            pvtBtns = (ctrlObj._schemaData && pvtBtns.length == 0) ? $(ctrlObj._schemaData.element.find(".schemaValue .pivotButton")) : pvtBtns;
                            for (i = 0; i < pvtBtns.length; i++) {
                                measureNames.push({
                                    "option": $(pvtBtns[i]).text(),
                                    "value": $(pvtBtns[i]).attr("tag").split(":")[1]
                                });
                            }
                        }
                        innerContent = !($(args["selectedArgs"].element).hasClass("topCount")) ?
                            (ej.buildTag("td", "<input type='text' id='filterMeasures' class='filterMeasures' />").attr("width", "180px")[0].outerHTML +
                            ej.buildTag("td", "<input type='text' id='filterOptions' class='filterOptions'/>").attr("width", "180px")[0].outerHTML +
                            ej.buildTag("td.filterValuesTd", "<input type='text' id='filterValue1' value='" + (args.filterInfo.length > 0 ? (opMode == ej.Pivot.OperationalMode.ClientMode ? args.filterInfo[0].values[0] : args.filterInfo[0].value1) : "") + "' style='display:inline; width:190px; height:19px;' class='filterValues'/>" + (colSpan == "4" ? "<span>" + ctrlObj._getLocalizedLabels("and") + " </span><input type='text' id='filterValue2' value='" + (args.filterInfo.length > 0 ? (opMode == ej.Pivot.OperationalMode.ClientMode && !ej.isNullOrUndefined(args.filterInfo[0].values[1])) ? args.filterInfo[0].values[1] : ((opMode == ej.Pivot.OperationalMode.ServerMode && !ej.isNullOrUndefined(args.filterInfo[0].value2)) ? args.filterInfo[0].value2 : "") : "") + "' style='display:inline; width:190px; height:19px;' class='filterValues'/> </br>" : "</br>"))[0].outerHTML) :

                            ej.buildTag("td", "<input type='text' id='filterOptions' class='filterOptions' />").attr("width", "80px")[0].outerHTML +
                            ej.buildTag("td", "<input type='text' id='filterValue1' class='filterValues' />").attr("width", "50px")[0].outerHTML +
                            ej.buildTag("td", "<input type='text' id='filterMeasures' class='filterMeasures' />").attr("width", "180px")[0].outerHTML;

                        dialogContent = ej.buildTag("table.valuefilter",
                            ej.buildTag("tr", ej.buildTag("td", (ctrlObj._getLocalizedLabels("ValueFilterLabel"))).attr("colspan", (args.text == "Between" ? "4" : "3"))[0].outerHTML)[0].outerHTML +
                            ej.buildTag("tr", innerContent)[0].outerHTML)[0].outerHTML;

                        dropdownValues = [{
                            value: "equals",
                            option: ctrlObj._getLocalizedLabels("Equals").toLowerCase()
                        },
                            {value: "not equals", option: ctrlObj._getLocalizedLabels("DoesNotEquals").toLowerCase()},
                            {value: "greater than", option: ctrlObj._getLocalizedLabels("IsGreaterThan").toLowerCase()},
                            {
                                value: "greater than or equal to",
                                option: ctrlObj._getLocalizedLabels("IsGreaterThanOrEqualTo").toLowerCase()
                            },
                            {value: "less than", option: ctrlObj._getLocalizedLabels("IsLessThan").toLowerCase()},
                            {
                                value: "less than or equal to",
                                option: ctrlObj._getLocalizedLabels("IsLessThanOrEqualTo").toLowerCase()
                            },
                            {value: "between", option: ctrlObj._getLocalizedLabels("Between").toLowerCase()},
                            {value: "not between", option: ctrlObj._getLocalizedLabels("NotBetween").toLowerCase()}];
                    }
                    var dialogFooter = ej.buildTag("div", ej.buildTag("button#filterDlgOKBtn.dialogOKBtn", "OK")[0].outerHTML + ej.buildTag("button#filterDlgCancelBtn.dialogCancelBtn", "Cancel")[0].outerHTML, {
                        "float": ctrlObj.model.enableRTL ? "left" : "right",
                        "margin": "8px 0 6px"
                    })[0].outerHTML;
                    ctrlObj.element.find(".e-dialog").remove();
                    $(ej.buildTag("div#filterDialog.filterDialog", dialogContent + dialogFooter, {"opacity": "1"})).appendTo("#" + ctrlObj._id);
                    ctrlObj.element.find(".filterDialog").ejDialog({
                        enableRTL: ctrlObj.model.enableRTL,
                        enableResize: false,
                        cssClass: "labelValueFilterDlg",
                        width: "auto",
                        content: "#" + ctrlObj._id,
                        close: ej.proxy(ej.Pivot.closePreventPanel, ctrlObj)
                    });
                    if (args.action == "valueFilterDlg") {
                        ctrlObj.element.find(".filterMeasures").ejDropDownList({
                            dataSource: measureNames,
                            width: "180px",
                            height: "25px",
                            fields: {text: "option", value: "value"},
                            create: function () {
                                $(this.wrapper.find('.e-input')).focus(function () {
                                    $(this).blur();
                                })
                            }
                        });
                        ctrlObj._measureDDL = ctrlObj.element.find(".filterMeasures").data("ejDropDownList");

                        var selectedMeasure = measureNames.length > 0 ? measureNames[0].value : (args.filterInfo.length > 0) ? args.filterInfo[0].measure : ""
                        if (selectedMeasure != "")
                            ctrlObj._measureDDL.selectItemByValue(selectedMeasure);
                    }

                    if ($(args["selectedArgs"].element).attr("id") == "topCount") {
                        ctrlObj.element.find("#filterOptions").ejDropDownList({
                            dataSource: [{option: "Top", value: "topCount"}, {option: "Bottom", value: "BottomCount"}],
                            fields: {text: "option", value: "value"},
                            value: (args.filterInfo.length > 0) ? args.filterInfo[0]["operator"] : "topCount",
                            create: function () {
                                $(this.wrapper.find('.e-input')).focus(function () {
                                    $(this).blur();
                                })
                            }
                        });
                        ctrlObj.element.find("#filterValue1").ejNumericTextbox({
                            value: (args.filterInfo.length > 0) ? parseInt(args.filterInfo[0].value1) : 5,
                            minValue: 1
                        });
                    }
                    else {
                        var selectedIndex = $(args.selectedArgs.element).parent().children("li:not(#sep)").index(args.selectedArgs.element)
                        ctrlObj.element.find(".filterOptions").ejDropDownList({
                            dataSource: dropdownValues, width: "180px",
                            height: "25px", fields: {value: "value", text: "option",},
                            selectedIndices: [selectedIndex - 1],
                            change: ej.proxy(ctrlObj._filterOptionChanged, ctrlObj),
                            create: function () {
                                $(this.wrapper.find('.e-input')).focus(function () {
                                    $(this).blur();
                                })
                            }
                        });
                        if ($(args.selectedArgs.element).length == 0) {
                            var filterDDL = ctrlObj.element.find(".filterOptions").data("ejDropDownList");
                            filterDDL.selectItemByValue(args.selectedArgs.selectedValue);
                        }
                    }
                    ctrlObj.element.find("#filterDlgOKBtn").ejButton({
                        type: ej.ButtonType.Button,
                        click: ej.proxy(ctrlObj._filterElementOkBtnClick, ctrlObj)
                    });
                    ctrlObj.element.find("#filterDlgCancelBtn").ejButton({
                        type: ej.ButtonType.Button, click: function () {
                            $(".e-dialog").hide();
                            ej.Pivot.closePreventPanel(ctrlObj);
                        }
                    });
                    ctrlObj.element.find(".e-titlebar").prepend(ej.buildTag("div", (args.action == "valueFilterDlg" ? (ctrlObj._getLocalizedLabels("ValueFilters") + "(") : (ctrlObj._getLocalizedLabels("LabelFilters") + "(") ) + (ctrlObj._selectedLevelUniqueName.indexOf(".") == -1 ? ctrlObj._selectedLevelUniqueName : (ctrlObj._selectedLevelUniqueName.indexOf(".") < 0 ? ctrlObj._selectedLevelUniqueName : ctrlObj._selectedLevelUniqueName.split('.')[2].replace(/\[/g, '').replace(/\]/g, ''))) + ")", {"display": "inline"}));
                }
                return filterTag;
            }
        }
        ej.Pivot.SortOrder = {
            None: "none",
            Ascending: "ascending",
            Descending: "descending"
        }

        ej.Pivot.AdvancedFilterType = {
            LabelFilter: "label",
            ValueFilter: "value"
        }

        ej.Pivot.ValueFilterOptions = {
            None: "none",
            Equals: "equals",
            NotEquals: "notequals",
            GreaterThan: "greaterthan",
            GreaterThanOrEqualTo: "greaterthanorequalto",
            LessThan: "lessthan",
            LessThanOrEqualTo: "lessthanorequalto",
            Between: "between",
            NotBetween: "notbetween"
        }

        ej.Pivot.LabelFilterOptions = {
            None: "none",
            BeginsWith: "beginswith",
            NotBeginsWith: "notbeginswith",
            EndsWith: "endswith",
            NotEndsWith: "notendswith",
            Contains: "contains",
            NotContains: "notcontains",
            Equals: "equals",
            NotEquals: "notequals",
            GreaterThan: "greaterthan",
            GreaterThanOrEqualTo: "greaterthanorequalto",
            LessThan: "lessthan",
            LessThanOrEqualTo: "lessthanorequalto",
            Between: "between",
            NotBetween: "notbetween"

        }
        ej.Pivot.AnalysisMode = {
            Olap: "olap",
            Pivot: "pivot"
        };
        ej.Pivot.OperationalMode = {
            ClientMode: "clientmode",
            ServerMode: "servermode"
        };
    })(jQuery, Syncfusion);
    ;

});