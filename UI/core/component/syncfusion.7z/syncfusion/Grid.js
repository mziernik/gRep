/**
 * Sekcja zawierająca nagłówek, treść oraz znacznik po lewej stronie
 * http://getbootstrap.com/components/#glyphicons-how-to-use
 */

import SyncfusionComponent from "./SyncfusionComponent.js";
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

import $ from "jquery";
import "./script/ej.grid";

export default class Grid extends SyncfusionComponent {

    constructor() {
        super(...arguments);
    }

    create(element: HTMLElement) {
        $(element).ejGrid({
            locale: "pl-PL",
            dataSource: [
                {
                    number: "Zgł/1/2017",
                    name: "Uszkodzona maszyna CNC",
                    priority: "Wysoki",
                    added: new Date(2017, 0, 1),
                    limit: new Date(2017, 0, 3),
                    stopped: false,
                    location: "Sala 34",
                    issue: "SP 123/2017"
                },
                {
                    number: "Zgł/2/2017",
                    name: "Drobne prace konserwatorskie",
                    priority: "Niski",
                    added: new Date(2017, 0, 2),
                    limit: new Date(2017, 0, 10),
                    stopped: true,
                    location: "Magazyn B",
                    issue: "SP M/2/2017"
                },
                {
                    number: "Zgł/3/2017",
                    name: "Aktualizacja oprogramowania",
                    priority: "Średni",
                    added: new Date(2017, 0, 13),
                    limit: new Date(2017, 0, 15),
                    stopped: false,
                    location: "Serwerownia",
                    issue: "SP S/1/2017"
                }
            ],
            allowPaging: true,
            allowResizing: true,
            enableHeaderHover: false,
            allowReordering: true,
            allowFiltering: true,
            filterSettings: {
                filterType: "excel"
            },
            allowGrouping: true,
            allowRowDragAndDrop: true,
            selectionType: "multiple",
            editSettings: {
                allowEditing: true,
                allowAdding: true,
                allowDeleting: true
            },
            toolbarSettings: {
                showToolbar: true,
                toolbarItems: [
                    ej.Grid.ToolBarItems.Search,
                    ej.Grid.ToolBarItems.Add,
                    ej.Grid.ToolBarItems.Edit,
                    ej.Grid.ToolBarItems.Delete,
                    ej.Grid.ToolBarItems.Update,
                    ej.Grid.ToolBarItems.Cancel
                ]
            },

            columns: [
                {
                    type: "checkbox",
                    width: 30
                },
                {
                    field: "number",
                    isPrimaryKey: true,
                    headerText: "Numer",
                    textAlign: ej.TextAlign.Right,
                    width: 90
                },
                {
                    field: "name",
                    headerText: 'Nazwa zgłoszenia'
                },
                {
                    field: "priority",
                    headerText: 'Priorytet',
                    editType: ej.Grid.EditingType.Dropdown,
                    width: 120
                },
                {
                    field: "added",
                    headerText: 'Zgłoszono',
                    editType: ej.Grid.EditingType.DatePicker,
                    format: "{0:dd/MMM/yyyy}",
                    width: 120
                },
                {
                    field: "limit",
                    headerText: 'Termin',
                    editType: ej.Grid.EditingType.DatePicker,
                    format: "{0:dd/MMM/yyyy}",
                    width: 120
                },
                {
                    field: "stopped",
                    headerText: 'Zatrzymano',
                    editType: ej.Grid.EditingType.CheckBox,
                    width: 120
                },
                {
                    field: "location",
                    headerText: 'Lokalizacja',
                    editType: ej.Grid.EditingType.Dropdown
                },
                {
                    field: "issue",
                    headerText: 'Nr sprawy'
                }
            ]
        });
        // $("#selection").ejDropDownList({width: "120px", change: "onSelectionTypeChange", selectedItemIndex: 0});


        // function onSelectionTypeChange(args) {
        //     $("#Grid").ejGrid("cancelEdit");
        //     $("#Grid").ejGrid("model.editSettings.rowPosition", args.selectedValue);
        // }
    }

    render() {
        return <div ref={e => this.create(e)}/>
    }

}